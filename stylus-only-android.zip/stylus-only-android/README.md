# Stylus Only (Android)

Draws only with the stylus you teach it. Fingers and palms are ignored.

## Get the APK with GitHub (no Android Studio needed)
1. On github.com create a new repository (any name, public or private).
2. Upload everything in this folder, including the hidden `.github` folder (use a computer browser: drag the folder contents into "Add file > Upload files").
3. Open the repository's **Actions** tab. The "Build APK" run starts by itself (or press "Run workflow").
4. When it turns green, open the run and download **stylus-only-apk** at the bottom. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone, tap it, and allow "install unknown apps" when asked.

## Using it
Tap **1 Learn stylus**, draw 5+ short lines with only the stylus, tap Done. Then **2 Learn finger**, touch 5+ times with finger/palm, tap Done.
