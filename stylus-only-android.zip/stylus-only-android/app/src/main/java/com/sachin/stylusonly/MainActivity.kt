package com.sachin.stylusonly

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var draw: DrawView
    private lateinit var hudView: TextView
    private lateinit var statusView: TextView
    private val colors = intArrayOf(Color.BLACK, 0xFF1F4FD8.toInt(), 0xFFD64545.toInt(), 0xFF1F9D55.toInt())
    private var ci = 0

    private fun btn(t: String, w: Float = 1f, f: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w)
        setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }
        hudView = TextView(this).apply { setPadding(16, 8, 16, 8); textSize = 13f; text = "Tap 1 Learn stylus first" }
        statusView = TextView(this).apply { setPadding(16, 4, 16, 4); textSize = 12f; gravity = Gravity.CENTER }
        draw = DrawView(this,
            { t, ok -> hudView.text = (if (ok) "Stylus accepted: " else "Ignored: ") + t },
            { m -> Toast.makeText(this, m, Toast.LENGTH_LONG).show() },
            { refresh() })
        val top = LinearLayout(this)
        top.addView(btn("Pen") { draw.eraser = false })
        top.addView(btn("Eraser") { draw.eraser = true })
        top.addView(btn("Color") { ci = (ci + 1) % colors.size; draw.color = colors[ci]; draw.eraser = false })
        top.addView(btn("Undo") { draw.undo() })
        top.addView(btn("Clear") { draw.clearAll() })
        val bottom = LinearLayout(this)
        lateinit var bs: Button
        lateinit var bf: Button
        bs = btn("1 Learn stylus") { draw.toggleLearn("stylus"); bs.text = if (draw.calibrating == "stylus") "Done" else "1 Learn stylus" }
        bf = btn("2 Learn finger") { draw.toggleLearn("finger"); bf.text = if (draw.calibrating == "finger") "Done" else "2 Learn finger" }
        bottom.addView(bs); bottom.addView(bf)
        root.addView(top); root.addView(hudView)
        root.addView(draw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(statusView); root.addView(bottom)
        setContentView(root)
        refresh()
    }

    private fun refresh() { statusView.text = draw.statusText() }
}
