package com.sachin.stylusonly

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View

class DrawView(
    ctx: Context,
    private val hud: (String, Boolean) -> Unit,
    private val toast: (String) -> Unit,
    private val onStatus: () -> Unit
) : View(ctx) {

    private class Pend(val id: Int, var size: Float, val tool: Int, val pts: ArrayList<PointF>)
    private class Stroke(val pts: ArrayList<PointF>, val color: Int, val width: Float, val eraser: Boolean, val cal: Boolean)

    private val strokes = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private val pend = LinkedHashMap<Int, Pend>()
    private val rejected = HashSet<Int>()
    private var active = -1
    private var activeY = 0f
    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false
    private val decideRun = Runnable { scheduled = false; decide() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dp = resources.displayMetrics.density

    var eraser = false
    var color = Color.BLACK
    var calibrating: String? = null

    private var mode = "none"   // none = not learned, size = match by contact size, pos = size not reported
    private var lo = 0f
    private var hi = 0f
    private val calS = ArrayList<Float>()
    private val calF = ArrayList<Float>()
    private val prefs = ctx.getSharedPreferences("so", Context.MODE_PRIVATE)

    init {
        setBackgroundColor(Color.WHITE)
        mode = prefs.getString("mode", "none") ?: "none"
        lo = prefs.getFloat("lo", 0f); hi = prefs.getFloat("hi", 0f)
        prefs.getString("S", "")?.split(",")?.mapNotNull { it.toFloatOrNull() }?.let { calS.addAll(it) }
        prefs.getString("F", "")?.split(",")?.mapNotNull { it.toFloatOrNull() }?.let { calF.addAll(it) }
    }

    fun statusText(): String = when (mode) {
        "size" -> "Stylus tip ${lo.toInt()} to ${hi.toInt()} (anything else is ignored)"
        "pos" -> "Phone reports no touch size: position rule only"
        else -> "Not learned: tap 1 and write with your stylus"
    }

    private fun sizeOf(e: MotionEvent, i: Int): Float {
        val m = e.getTouchMajor(i)
        return if (m > 0f) m else e.getSize(i) * 1000f
    }

    private fun matches(p: Pend): Boolean {
        if (p.tool == MotionEvent.TOOL_TYPE_STYLUS || p.tool == MotionEvent.TOOL_TYPE_ERASER) return true
        return when (mode) { "size" -> p.size in lo..hi; "pos" -> true; else -> false }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pend.clear(); rejected.clear(); addPend(e, 0) }
            MotionEvent.ACTION_POINTER_DOWN -> addPend(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e, i)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> { pend.clear(); rejected.clear(); cur = null; active = -1; invalidate() }
        }
        return true
    }

    private fun addPend(e: MotionEvent, i: Int) {
        val id = e.getPointerId(i)
        pend[id] = Pend(id, sizeOf(e, i), e.getToolType(i), arrayListOf(PointF(e.getX(i), e.getY(i))))
        if (!scheduled) { scheduled = true; handler.postDelayed(decideRun, 45) }
    }

    private fun move(e: MotionEvent, i: Int) {
        val id = e.getPointerId(i)
        if (rejected.contains(id)) return
        val p = pend[id]
        if (p != null) {
            p.size = maxOf(p.size, sizeOf(e, i)); p.pts.add(PointF(e.getX(i), e.getY(i))); return
        }
        val c = cur
        if (id != active || c == null) return
        for (h in 0 until e.historySize) c.pts.add(PointF(e.getHistoricalX(i, h), e.getHistoricalY(i, h)))
        c.pts.add(PointF(e.getX(i), e.getY(i)))
        // a contact that suddenly grows is a palm landing on the stylus
        if (calibrating == null && mode == "size" && sizeOf(e, i) > hi * 1.5f && e.getToolType(i) == MotionEvent.TOOL_TYPE_FINGER) {
            rejected.add(id); cur = null; active = -1; hud("contact grew (palm)", false)
        }
        invalidate()
    }

    private fun up(id: Int) {
        if (rejected.remove(id)) return
        if (pend.containsKey(id)) { handler.removeCallbacks(decideRun); scheduled = false; decide() }
        if (id == active) { cur?.let { if (!it.cal) strokes.add(it) }; cur = null; active = -1; invalidate() }
        pend.remove(id)
    }

    private fun decide() {
        if (pend.isEmpty()) return
        val list = ArrayList(pend.values); pend.clear()
        calibrating?.let { k -> list.forEach { (if (k == "stylus") calS else calF).add(it.size) } }
        var cand = ArrayList<Pend>()
        for (p in list) {
            if (calibrating == null && !matches(p)) {
                rejected.add(p.id)
                hud(if (mode == "none") "tap 1 Learn stylus first" else "size ${p.size.toInt()} is not your stylus", false)
            } else cand.add(p)
        }
        if (cand.isEmpty()) return
        if (active != -1) {
            // a contact higher on screen than the current writer is the real tip, the current one was the palm
            val sw = ArrayList<Pend>()
            for (p in cand) {
                if (p.pts[0].y < activeY - 25 * dp) { rejected.add(active); cur = null; active = -1; invalidate(); sw.add(p) }
                else { rejected.add(p.id); hud("lower than the writing tip (palm)", false) }
            }
            cand = sw
            if (cand.isEmpty()) return
        }
        val known = cand.all { it.size > 0f }
        cand.sortWith(Comparator { a, b -> if (known) a.size.compareTo(b.size) else a.pts[0].y.compareTo(b.pts[0].y) })
        for (i in 1 until cand.size) rejected.add(cand[i].id)
        val w = cand[0]
        hud("size ${w.size.toInt()}", true)
        active = w.id; activeY = w.pts[0].y
        cur = Stroke(w.pts, color, 4f * dp, eraser, calibrating != null)
        invalidate()
    }

    fun toggleLearn(kind: String) {
        if (calibrating == kind) {
            calibrating = null; cur = null; active = -1; learn(); invalidate(); return
        }
        if (calibrating != null) { toast("Finish the current step first"); return }
        calibrating = kind
        if (kind == "stylus") calS.clear() else calF.clear()
        toast(if (kind == "stylus") "Draw 5 or more short separate lines with ONLY the stylus, then tap Done"
              else "Touch the screen 5 or more times with a finger or palm, then tap Done")
    }

    private fun learn() {
        prefs.edit().putString("S", calS.joinToString(",")).putString("F", calF.joinToString(",")).apply()
        val s = calS.filter { it > 0f }
        if (calS.size < 3) { toast("Draw at least 3 separate short lines with the stylus first"); return }
        if (s.size < 3) {
            mode = "pos"; prefs.edit().putString("mode", mode).apply(); onStatus()
            toast("This phone reports no touch size to apps, so it cannot tell a finger from the stylus. Only the position rule is active."); return
        }
        val smin = s.min(); val smax = s.max()
        lo = smin * 0.7f; hi = smax * 1.25f
        var msg = "Learned: stylus contact is ${smin.toInt()} to ${smax.toInt()}, accepted up to ${hi.toInt()}."
        val f = calF.filter { it > 0f }
        if (f.size >= 3) {
            val fmin = f.min()
            if (fmin > smax) hi = minOf(hi, (smax + fmin) / 2f)
            else msg += " Finger and stylus sizes overlap, so some touches may get through."
        } else msg += " Now tap 2 and touch with a finger to improve accuracy."
        mode = "size"
        prefs.edit().putString("mode", mode).putFloat("lo", lo).putFloat("hi", hi).apply()
        onStatus(); toast(msg)
    }

    fun undo() { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1); invalidate() }
    fun clearAll() { strokes.clear(); invalidate() }

    private fun path(p: List<PointF>): Path {
        val path = Path()
        if (p.isEmpty()) return path
        path.moveTo(p[0].x, p[0].y)
        if (p.size == 1) { path.lineTo(p[0].x + 0.1f, p[0].y); return path }
        for (i in 1 until p.size - 1) path.quadTo(p[i].x, p[i].y, (p[i].x + p[i + 1].x) / 2, (p[i].y + p[i + 1].y) / 2)
        path.lineTo(p.last().x, p.last().y)
        return path
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        paint.color = if (s.eraser) Color.WHITE else s.color
        paint.strokeWidth = if (s.eraser) s.width * 4 else s.width
        c.drawPath(path(s.pts), paint)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.WHITE)
        for (s in strokes) drawStroke(c, s)
        cur?.let { drawStroke(c, it) }
    }
}
