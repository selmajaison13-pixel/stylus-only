plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sachin.stylusonly"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sachin.stylusonly"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "4.1"
    }
    // One fixed signing key: every build is signed the same, so a new APK installs OVER the old one
    // and your notes stay. (Only the very first switch from an older build needs an uninstall.)
    signingConfigs {
        getByName("debug") {
            storeFile = file("stylus-notes.keystore")
            storePassword = "stylus123"
            keyAlias = "stylus"
            keyPassword = "stylus123"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
