package com.sachin.stylusonly

import android.content.Context
import android.content.SharedPreferences

/** All user settings (notebook look, pen, touch rules, writing lock). Saved automatically. */
class Cfg(ctx: Context) {
    val prefs: SharedPreferences = ctx.getSharedPreferences("so", Context.MODE_PRIVATE)

    var paper = 1                 // 0 blank, 1 lines, 2 grid, 3 dots
    var paperColor = 0
    var lineColor = 0
    var spacing = 26              // page units between lines (A4 page is 595 x 842 units)
    var leftMargin = true
    var leftMarginPos = 56
    var topMargin = 60
    var pen = 7                   // in half unit steps
    var eraser = 30               // units
    var strict = 60               // 0..100
    var showInfo = true
    var keepOn = true
    var dots = true
    // auto move (like Excel): page moves by itself when the pen reaches the edge
    var autoScroll = true
    var edgeZone = 56             // dp
    var scrollSpeed = 6           // 1..15
    var autoPage = true           // A4: add a new page when you reach the end
    // writing lock
    var immersive = true          // hide status and navigation bars in the editor
    var blockGestures = true      // ask Android to ignore edge swipes while writing
    var hideWhileWriting = true   // tool bar disappears while the pen is on the page

    init { load() }

    fun load() {
        paper = prefs.getInt("paper", 1)
        paperColor = prefs.getInt("paperColor", 0)
        lineColor = prefs.getInt("lineColor", 0)
        spacing = prefs.getInt("spacingU", 26)
        leftMargin = prefs.getBoolean("leftMargin", true)
        leftMarginPos = prefs.getInt("leftMarginPosU", 56)
        topMargin = prefs.getInt("topMarginU", 60)
        pen = prefs.getInt("penU", 7)
        eraser = prefs.getInt("eraserU", 30)
        strict = prefs.getInt("strict", 60)
        showInfo = prefs.getBoolean("showInfo", true)
        keepOn = prefs.getBoolean("keepOn", true)
        dots = prefs.getBoolean("dots", true)
        autoScroll = prefs.getBoolean("autoScroll", true)
        edgeZone = prefs.getInt("edgeZone", 56)
        scrollSpeed = prefs.getInt("scrollSpeed", 6)
        autoPage = prefs.getBoolean("autoPage", true)
        immersive = prefs.getBoolean("immersive", true)
        blockGestures = prefs.getBoolean("blockGestures", true)
        hideWhileWriting = prefs.getBoolean("hideWhileWriting", true)
    }

    fun penU(): Float = pen / 2f

    fun save() {
        prefs.edit()
            .putInt("paper", paper).putInt("paperColor", paperColor).putInt("lineColor", lineColor)
            .putInt("spacingU", spacing).putBoolean("leftMargin", leftMargin)
            .putInt("leftMarginPosU", leftMarginPos).putInt("topMarginU", topMargin)
            .putInt("penU", pen).putInt("eraserU", eraser)
            .putInt("strict", strict).putBoolean("showInfo", showInfo).putBoolean("keepOn", keepOn).putBoolean("dots", dots)
            .putBoolean("autoScroll", autoScroll).putInt("edgeZone", edgeZone).putInt("scrollSpeed", scrollSpeed)
            .putBoolean("autoPage", autoPage).putBoolean("immersive", immersive)
            .putBoolean("blockGestures", blockGestures).putBoolean("hideWhileWriting", hideWhileWriting)
            .apply()
    }

    companion object {
        val PAPER = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFF8E6.toInt(), 0xFFFFF3A8.toInt(), 0xFFECEFF1.toInt())
        val PAPER_NAMES = listOf("White", "Cream", "Yellow", "Gray")
        val LINE = intArrayOf(0xFF9DB8E0.toInt(), 0xFFBDBDBD.toInt(), 0xFFA5D6A7.toInt())
        val LINE_NAMES = listOf("Blue", "Gray", "Green")
        val MARGIN = 0xFFE57373.toInt()
        /** keys that belong to the stylus learning of THIS phone: not put into backups */
        val DEVICE_KEYS = setOf("mode", "smin", "smax", "fmin", "SF", "FF", "fpLo", "fpHi", "toolOnly", "hn", "hxm", "hym", "hxs", "hys")
    }
}
