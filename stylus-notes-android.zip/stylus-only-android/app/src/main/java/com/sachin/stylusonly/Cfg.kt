package com.sachin.stylusonly

import android.content.Context
import android.content.SharedPreferences

/** All user settings (notebook look, pen, touch rules). Saved automatically. */
class Cfg(ctx: Context) {
    val prefs: SharedPreferences = ctx.getSharedPreferences("so", Context.MODE_PRIVATE)

    var paper = prefs.getInt("paper", 1)               // 0 blank, 1 lines, 2 grid, 3 dots
    var paperColor = prefs.getInt("paperColor", 0)
    var lineColor = prefs.getInt("lineColor", 0)
    var spacing = prefs.getInt("spacing", 34)          // dp between lines
    var leftMargin = prefs.getBoolean("leftMargin", true)
    var leftMarginPos = prefs.getInt("leftMarginPos", 64)  // dp from page left edge
    var topMargin = prefs.getInt("topMargin", 80)      // dp before the first line
    var pen = prefs.getInt("pen", 6)                   // in half dp steps
    var eraser = prefs.getInt("eraser", 22)            // dp
    var twoFinger = prefs.getBoolean("twoFinger", true)
    var pinch = prefs.getBoolean("pinch", true)
    var strict = prefs.getInt("strict", 60)            // 0..100
    var showInfo = prefs.getBoolean("showInfo", true)
    var keepOn = prefs.getBoolean("keepOn", true)

    fun penDp(): Float = pen / 2f

    fun save() {
        prefs.edit()
            .putInt("paper", paper).putInt("paperColor", paperColor).putInt("lineColor", lineColor)
            .putInt("spacing", spacing).putBoolean("leftMargin", leftMargin)
            .putInt("leftMarginPos", leftMarginPos).putInt("topMargin", topMargin)
            .putInt("pen", pen).putInt("eraser", eraser)
            .putBoolean("twoFinger", twoFinger).putBoolean("pinch", pinch)
            .putInt("strict", strict).putBoolean("showInfo", showInfo).putBoolean("keepOn", keepOn)
            .apply()
    }

    companion object {
        val PAPER = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFF8E6.toInt(), 0xFFFFF3A8.toInt(), 0xFFECEFF1.toInt())
        val PAPER_NAMES = listOf("White", "Cream", "Yellow", "Gray")
        val LINE = intArrayOf(0xFF9DB8E0.toInt(), 0xFFBDBDBD.toInt(), 0xFFA5D6A7.toInt())
        val LINE_NAMES = listOf("Blue", "Gray", "Green")
        val MARGIN = 0xFFE57373.toInt()
    }
}
