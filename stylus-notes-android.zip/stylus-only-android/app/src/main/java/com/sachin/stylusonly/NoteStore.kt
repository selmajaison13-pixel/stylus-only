package com.sachin.stylusonly

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.PointF
import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.OutputStreamWriter
import kotlin.math.max

/** One pen or eraser stroke. Points are in page units (A4 page = 595 x 842). */
class Stroke(val color: Int, val width: Float, val eraser: Boolean, val cal: Boolean) {
    val pts = ArrayList<PointF>()
    var path: android.graphics.Path? = null
    var pathN = -1
    var done = false
    var bounds: android.graphics.RectF? = null
}

const val MODE_A4 = "a4"
const val MODE_FREE = "free"

class Note(
    var id: String,
    var title: String,
    var created: Long,
    var modified: Long,
    var mode: String,
    var pages: Int
) {
    var strokeCount = 0
    var vx = 0f          // page unit at the left edge of the screen
    var vy = 0f          // page unit at the top edge of the screen
    var zf = 1f          // zoom (1 = one unit per dp)
    val strokes = ArrayList<Stroke>()
}

class ImportData(val notes: List<Note>, val settings: Map<String, Any>)

class NoteStore(private val dir: File) {
    private val notesDir = File(dir, "notes").apply { mkdirs() }
    private val thumbDir = File(dir, "thumbs").apply { mkdirs() }

    fun fileOf(id: String) = File(notesDir, "$id.json")
    fun thumbFile(id: String) = File(thumbDir, "$id.png")

    fun newId(): String = java.lang.Long.toString(System.currentTimeMillis(), 36) + java.lang.Integer.toString((Math.random() * 46656).toInt(), 36)

    // ---------- list ----------

    @Synchronized
    fun list(): List<Note> {
        val out = ArrayList<Note>()
        val files = notesDir.listFiles() ?: return out
        for (f in files) {
            if (!f.name.endsWith(".json")) continue
            try {
                InputStreamReader(FileInputStream(f), "UTF-8").use { rd ->
                    val r = JsonReader(rd)
                    val n = readNote(r, true)
                    if (n != null) out.add(n)
                }
            } catch (ex: Exception) { }
        }
        out.sortByDescending { it.modified }
        return out
    }

    @Synchronized
    fun load(id: String): Note? {
        return try {
            InputStreamReader(FileInputStream(fileOf(id)), "UTF-8").use { rd -> readNote(JsonReader(rd), false) }
        } catch (ex: Exception) { null }
    }

    /** writes to a temporary file first, so a crash while saving never damages the note */
    @Synchronized
    fun save(n: Note) {
        try {
            val tmp = File(notesDir, n.id + ".json.tmp")
            JsonWriter(OutputStreamWriter(BufferedOutputStream(FileOutputStream(tmp)), "UTF-8")).use { w -> writeNote(w, n) }
            val dst = fileOf(n.id)
            if (dst.exists()) dst.delete()
            tmp.renameTo(dst)
        } catch (ex: Exception) { }
    }

    @Synchronized
    fun saveThumb(id: String, bmp: Bitmap) {
        try { FileOutputStream(thumbFile(id)).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) } } catch (ex: Exception) { }
    }

    @Synchronized
    fun delete(id: String) { fileOf(id).delete(); thumbFile(id).delete() }

    // ---------- JSON ----------

    private fun r1(v: Float): Double = Math.round(v * 10f) / 10.0

    private fun writeNote(w: JsonWriter, n: Note) {
        w.beginObject()
        w.name("id").value(n.id)
        w.name("title").value(n.title)
        w.name("created").value(n.created)
        w.name("modified").value(n.modified)
        w.name("mode").value(n.mode)
        w.name("pages").value(n.pages.toLong())
        w.name("count").value(n.strokes.size.toLong())
        w.name("view").beginObject()
        w.name("x").value(r1(n.vx)); w.name("y").value(r1(n.vy)); w.name("z").value(r1(n.zf))
        w.endObject()
        w.name("strokes").beginArray()
        for (s in n.strokes) {
            w.beginObject()
            w.name("c").value(s.color.toLong())
            w.name("w").value(r1(s.width))
            w.name("e").value(s.eraser)
            w.name("p").beginArray()
            for (p in s.pts) { w.value(r1(p.x)); w.value(r1(p.y)) }
            w.endArray()
            w.endObject()
        }
        w.endArray()
        w.endObject()
    }

    /** headerOnly = read the name, dates and size only and stop (fast, used for the list) */
    private fun readNote(r: JsonReader, headerOnly: Boolean): Note? {
        var id = ""; var title = "Note"; var created = 0L; var modified = 0L; var mode = MODE_A4; var pages = 1; var count = 0
        var vx = 0f; var vy = 0f; var zf = 1f
        val strokes = ArrayList<Stroke>()
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "id" -> id = r.nextString()
                "title" -> title = r.nextString()
                "created" -> created = r.nextLong()
                "modified" -> modified = r.nextLong()
                "mode" -> mode = r.nextString()
                "pages" -> pages = r.nextInt()
                "count" -> count = r.nextInt()
                "view" -> {
                    r.beginObject()
                    while (r.hasNext()) when (r.nextName()) {
                        "x" -> vx = r.nextDouble().toFloat()
                        "y" -> vy = r.nextDouble().toFloat()
                        "z" -> zf = r.nextDouble().toFloat()
                        else -> r.skipValue()
                    }
                    r.endObject()
                }
                "strokes" -> {
                    if (headerOnly) {
                        return mk(id, title, created, modified, mode, pages, count, vx, vy, zf, strokes)
                    }
                    r.beginArray()
                    while (r.hasNext()) {
                        var col = 0; var wd = 2f; var er = false
                        val xs = ArrayList<Float>()
                        r.beginObject()
                        while (r.hasNext()) when (r.nextName()) {
                            "c" -> col = r.nextLong().toInt()
                            "w" -> wd = r.nextDouble().toFloat()
                            "e" -> er = r.nextBoolean()
                            "p" -> { r.beginArray(); while (r.hasNext()) xs.add(r.nextDouble().toFloat()); r.endArray() }
                            else -> r.skipValue()
                        }
                        r.endObject()
                        val s = Stroke(col, wd, er, false)
                        var i = 0
                        while (i + 1 < xs.size) { s.pts.add(PointF(xs[i], xs[i + 1])); i += 2 }
                        s.done = true
                        strokes.add(s)
                    }
                    r.endArray()
                }
                else -> r.skipValue()
            }
        }
        r.endObject()
        if (id.isEmpty()) return null
        return mk(id, title, created, modified, mode, pages, count, vx, vy, zf, strokes)
    }

    private fun mk(id: String, title: String, created: Long, modified: Long, mode: String, pages: Int, count: Int,
                   vx: Float, vy: Float, zf: Float, strokes: ArrayList<Stroke>): Note? {
        if (id.isEmpty()) return null
        val n = Note(id, title, created, modified, if (mode == MODE_FREE) MODE_FREE else MODE_A4, max(1, pages))
        n.vx = vx; n.vy = vy; n.zf = zf; n.strokeCount = max(count, strokes.size)
        n.strokes.addAll(strokes)
        return n
    }

    // ---------- backup and restore ----------

    /** ids = null means every note. Settings are included when settings != null. */
    fun writeBackup(out: OutputStream, ids: List<String>?, settings: SharedPreferences?) {
        val w = JsonWriter(OutputStreamWriter(BufferedOutputStream(out), "UTF-8"))
        w.setIndent("")
        w.beginObject()
        w.name("app").value("StylusNotes")
        w.name("format").value(2L)
        w.name("exported").value(System.currentTimeMillis())
        if (settings != null) {
            w.name("settings").beginObject()
            for ((k, v) in settings.all) {
                if (k in Cfg.DEVICE_KEYS) continue
                when (v) {
                    is Boolean -> w.name(k).value(v)
                    is Int -> w.name(k).value(v.toLong())
                    is Long -> w.name(k).value(v)
                    is String -> w.name(k).value(v)
                    else -> { }
                }
            }
            w.endObject()
        }
        w.name("notes").beginArray()
        val src = ids ?: list().map { it.id }
        for (id in src) {
            val n = load(id) ?: continue
            writeNote(w, n)
        }
        w.endArray()
        w.endObject()
        w.flush()
        w.close()
    }

    fun readBackup(input: InputStream): ImportData {
        val r = JsonReader(InputStreamReader(BufferedInputStream(input), "UTF-8"))
        val notes = ArrayList<Note>()
        val settings = LinkedHashMap<String, Any>()
        var isOurs = false
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "app" -> isOurs = r.nextString() == "StylusNotes"
                "settings" -> {
                    r.beginObject()
                    while (r.hasNext()) {
                        val k = r.nextName()
                        when (r.peek()) {
                            JsonToken.BOOLEAN -> settings[k] = r.nextBoolean()
                            JsonToken.NUMBER -> settings[k] = r.nextLong().toInt()
                            JsonToken.STRING -> settings[k] = r.nextString()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                }
                "notes" -> {
                    r.beginArray()
                    while (r.hasNext()) { val n = readNote(r, false); if (n != null) notes.add(n) }
                    r.endArray()
                }
                else -> r.skipValue()
            }
        }
        r.endObject()
        r.close()
        if (!isOurs) throw IllegalStateException("This is not a Stylus Notes backup file")
        return ImportData(notes, settings)
    }

    fun exists(id: String) = fileOf(id).exists()

    // ---------- the single page of the very first version ----------

    /** version 1 kept one endless page in page.bin (pixels). It becomes a normal unlimited note. */
    @Synchronized
    fun migrateOld(density: Float): Boolean {
        val f = File(dir, "page.bin")
        if (!f.exists()) return false
        try {
            val n = Note(newId(), "My first page", System.currentTimeMillis(), System.currentTimeMillis(), MODE_FREE, 1)
            DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
                if (i.readInt() != 1) return false
                val tx = i.readFloat(); val ty = i.readFloat(); val sc = i.readFloat()
                n.vx = -tx / (sc * density); n.vy = -ty / (sc * density); n.zf = sc
                val cnt = i.readInt()
                for (k in 0 until cnt) {
                    val col = i.readInt(); val w = i.readFloat(); val er = i.readBoolean(); val m = i.readInt()
                    val s = Stroke(col, w / density, er, false)
                    for (j in 0 until m) s.pts.add(PointF(i.readFloat() / density, i.readFloat() / density))
                    s.done = true
                    n.strokes.add(s)
                }
            }
            save(n)
            f.renameTo(File(dir, "page.bin.old"))
            return true
        } catch (ex: Exception) { return false }
    }
}
