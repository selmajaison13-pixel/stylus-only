package com.sachin.stylusonly

import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.MotionEvent
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One finished contact (finger, palm or stylus) with everything the app measured about it. */
class Rec(val label: String, val tool: Int) {
    var dur = 0L
    var samples = 0
    var conc = 1            // contacts on the glass when it landed (itself included)
    var order = 0           // 0 = landed first in its gesture
    var x0 = 0f             // landing position in dp
    var y0 = 0f
    var t0 = 0L             // landing time in ms after the gesture began
    val f = FloatArray(NFEAT)
    var state = ""
    var why = ""
    var cancelled = false
    var isPen = false       // set when the gesture is closed: the contact that moved most
    var relX = 0f           // position relative to the pen contact of the same gesture, dp
    var relY = 0f

    companion object {
        const val NFEAT = 12
        const val NSTATIC = 6   // the first six do not depend on how the contact moved
        val NAMES = arrayOf("size", "minor", "pressure", "area", "round", "wobble",
            "path", "speed", "speedCv", "turn", "dur", "samples")
    }
}

/** One gesture: everything from the first finger down to the last finger up. */
class Sess(val label: String) {
    val recs = ArrayList<Rec>()
    var cancelled = false
    var maxConc = 0
}

/** Where the resting hand usually lands relative to the pen tip (learned from natural writing). */
class HandModel(val mx: Float, val my: Float, val sx: Float, val sy: Float, val n: Int) {
    /** 0 = exactly where the hand usually is; larger = less hand-like (capped at 9) */
    fun cost(dx: Float, dy: Float): Float {
        val a = (dx - mx) / sx
        val b = (dy - my) / sy
        return min(9f, a * a + b * b)
    }
}

class Recorder(private val file: File) {
    val sessions = ArrayList<Sess>()
    var label = "U"                       // S stylus learning, F fingers and palm, N natural writing, U normal use
    private val ui = Handler(Looper.getMainLooper())
    private val saveRun = Runnable { saveNow() }

    // raw event statistics
    private val toolSeen = HashMap<Int, Int>()
    private val hoverSeen = HashMap<Int, Int>()
    private val axisNonZero = HashMap<String, Int>()
    private val pressVals = LinkedHashSet<Float>()
    private var events = 0
    private var deviceIds = LinkedHashSet<Int>()

    init { load() }

    // ---------- raw events ----------

    fun noteHover(e: MotionEvent) {
        val t = e.getToolType(0)
        hoverSeen[t] = (hoverSeen[t] ?: 0) + 1
    }

    fun noteEvent(e: MotionEvent, i: Int) {
        events++
        deviceIds.add(e.deviceId)
        val t = e.getToolType(i)
        toolSeen[t] = (toolSeen[t] ?: 0) + 1
        bump("touchMajor", e.getTouchMajor(i))
        bump("touchMinor", e.getTouchMinor(i))
        bump("toolMajor", e.getToolMajor(i))
        bump("size", e.getSize(i))
        bump("orientation", e.getOrientation(i))
        bump("distance", e.getAxisValue(MotionEvent.AXIS_DISTANCE, i))
        val p = e.getPressure(i)
        if (pressVals.size < 8) pressVals.add(Math.round(p * 1000f) / 1000f)
        if (p != 1f && p != 0f) axisNonZero["pressure not 0 or 1"] = (axisNonZero["pressure not 0 or 1"] ?: 0) + 1
    }

    private fun bump(name: String, v: Float) {
        if (v != 0f) axisNonZero[name] = (axisNonZero[name] ?: 0) + 1
    }

    // ---------- sessions ----------

    fun add(s: Sess) {
        if (s.recs.isEmpty()) return
        closeSession(s)
        sessions.add(s)
        // keep the file small: normal use keeps only the latest 60 gestures, learning data at most 500 contacts per kind
        var u = 0
        for (x in sessions) if (x.label == "U") u++
        var i = 0
        while (u > 60 && i < sessions.size) {
            if (sessions[i].label == "U") { sessions.removeAt(i); u-- } else i++
        }
        for (lab in arrayOf("S", "F", "N")) {
            var n = 0
            for (x in sessions) if (x.label == lab) n += x.recs.size
            var j = 0
            while (n > 500 && j < sessions.size) {
                if (sessions[j].label == lab) { n -= sessions[j].recs.size; sessions.removeAt(j) } else j++
            }
        }
        ui.removeCallbacks(saveRun)
        ui.postDelayed(saveRun, 2500)
    }

    /** marks which contact was the pen (the one that moved most) and measures the others relative to it */
    private fun closeSession(s: Sess) {
        var pen: Rec? = null
        for (r in s.recs) if (pen == null || r.f[6] > pen.f[6]) pen = r
        val p = pen ?: return
        for (r in s.recs) {
            r.isPen = (r === p)
            r.relX = r.x0 - p.x0
            r.relY = r.y0 - p.y0
        }
        if (s.label == "S") for (r in s.recs) { r.isPen = true }   // everything in a stylus-only step is the stylus
    }

    fun clearLabel(lab: String) {
        val iter = sessions.iterator()
        while (iter.hasNext()) if (iter.next().label == lab) iter.remove()
        saveNow()
    }

    fun clearAll() { sessions.clear(); toolSeen.clear(); hoverSeen.clear(); axisNonZero.clear(); pressVals.clear(); events = 0; saveNow() }

    fun contactCount(lab: String): Int { var n = 0; for (s in sessions) if (s.label == lab) n += s.recs.size; return n }

    /** gestures where the hand touched while the pen wrote and the pen clearly moved */
    fun usableNatural(): List<Sess> {
        val out = ArrayList<Sess>()
        for (s in sessions) if (s.label == "N" && usable(s)) out.add(s)
        return out
    }

    private fun usable(s: Sess): Boolean {
        if (s.recs.size < 2 || s.cancelled) return false
        var best = 0f; var second = 0f
        for (r in s.recs) { if (r.f[6] > best) { second = best; best = r.f[6] } else if (r.f[6] > second) second = r.f[6] }
        return best >= 25f && second < best * 0.6f
    }

    fun buildHandModel(exclude: Sess?): HandModel? {
        val xs = ArrayList<Float>(); val ys = ArrayList<Float>()
        for (s in sessions) {
            if (s === exclude || s.label != "N" || !usable(s)) continue
            for (r in s.recs) if (!r.isPen) { xs.add(r.relX); ys.add(r.relY) }
        }
        if (xs.size < 5) return null
        val mx = med(xs); val my = med(ys)
        val dx = ArrayList<Float>(); val dy = ArrayList<Float>()
        for (v in xs) dx.add(abs(v - mx))
        for (v in ys) dy.add(abs(v - my))
        val sx = max(20f, med(dx) * 1.48f * 2f)
        val sy = max(20f, med(dy) * 1.48f * 2f)
        return HandModel(mx, my, sx, sy, xs.size)
    }

    // ---------- saving ----------

    private fun clean(s: String) = s.replace('|', '/').replace('\n', ' ').replace(';', ',')

    fun saveNow() {
        try {
            val sb = StringBuilder()
            for (s in sessions) {
                sb.append("G|").append(s.label).append('|').append(if (s.cancelled) 1 else 0).append('|').append(s.maxConc).append('\n')
                for (r in s.recs) {
                    sb.append("C|").append(r.tool).append('|').append(r.dur).append('|').append(r.samples).append('|')
                        .append(r.conc).append('|').append(r.order).append('|').append(r.x0).append('|').append(r.y0).append('|')
                        .append(r.t0).append('|').append(clean(r.state)).append('|').append(clean(r.why)).append('|')
                        .append(if (r.cancelled) 1 else 0).append('|').append(if (r.isPen) 1 else 0).append('|')
                        .append(r.relX).append('|').append(r.relY).append('|')
                    for (k in 0 until Rec.NFEAT) { if (k > 0) sb.append(','); sb.append(r.f[k]) }
                    sb.append('\n')
                }
            }
            file.writeText(sb.toString())
        } catch (e: Exception) { }
    }

    private fun load() {
        try {
            if (!file.exists()) return
            var cur: Sess? = null
            for (line in file.readLines()) {
                val p = line.split("|")
                if (p[0] == "G" && p.size >= 4) {
                    val s = Sess(p[1]); s.cancelled = p[2] == "1"; s.maxConc = p[3].toIntOrNull() ?: 0
                    sessions.add(s); cur = s
                } else if (p[0] == "C" && p.size >= 16 && cur != null) {
                    val r = Rec(cur.label, p[1].toIntOrNull() ?: 0)
                    r.dur = p[2].toLongOrNull() ?: 0L; r.samples = p[3].toIntOrNull() ?: 0
                    r.conc = p[4].toIntOrNull() ?: 1; r.order = p[5].toIntOrNull() ?: 0
                    r.x0 = p[6].toFloatOrNull() ?: 0f; r.y0 = p[7].toFloatOrNull() ?: 0f
                    r.t0 = p[8].toLongOrNull() ?: 0L
                    r.state = p[9]; r.why = p[10]; r.cancelled = p[11] == "1"; r.isPen = p[12] == "1"
                    r.relX = p[13].toFloatOrNull() ?: 0f; r.relY = p[14].toFloatOrNull() ?: 0f
                    val fv = p[15].split(",")
                    for (k in 0 until min(Rec.NFEAT, fv.size)) r.f[k] = fv[k].toFloatOrNull() ?: 0f
                    cur.recs.add(r)
                }
            }
        } catch (e: Exception) { sessions.clear() }
    }

    // ---------- statistics helpers ----------

    private fun med(v: List<Float>): Float {
        if (v.isEmpty()) return 0f
        val s = v.sorted()
        return s[s.size / 2]
    }

    private fun q(s: List<Float>, f: Float): Float = s[min(s.size - 1, (f * (s.size - 1) + 0.5f).toInt())]

    private fun f1(v: Float): String = "%.1f".format(v)
    private fun f2(v: Float): String = "%.2f".format(v)

    private fun statLine(name: String, v: List<Float>): String {
        if (v.isEmpty()) return "  $name: no data"
        val s = v.sorted()
        return "  $name n${s.size} min ${f1(s.first())} p10 ${f1(q(s, 0.1f))} med ${f1(q(s, 0.5f))} p90 ${f1(q(s, 0.9f))} max ${f1(s.last())}"
    }

    /** best single threshold that separates pen values from hand values: returns text and balanced accuracy */
    private fun split(pen: List<Float>, hand: List<Float>): Pair<String, Float> {
        if (pen.size < 3 || hand.size < 3) return Pair("not enough data", -1f)
        val all = (pen + hand).sorted().distinct()
        if (all.size < 2) return Pair("every contact reads the same value (${f1(all[0])})", 0.5f)
        var bestAcc = 0f; var bestTxt = ""
        for (i in 0 until all.size - 1) {
            val thr = (all[i] + all[i + 1]) / 2f
            val penBelow = pen.count { it < thr } / pen.size.toFloat()
            val handBelow = hand.count { it < thr } / hand.size.toFloat()
            val accLow = (penBelow + (1f - handBelow)) / 2f     // pen is below the threshold
            val accHigh = 1f - accLow                           // pen is above the threshold
            if (accLow > bestAcc) { bestAcc = accLow; bestTxt = "pen is below ${f2(thr)}" }
            if (accHigh > bestAcc) { bestAcc = accHigh; bestTxt = "pen is above ${f2(thr)}" }
        }
        return Pair(bestTxt, bestAcc)
    }

    private fun toolName(t: Int): String = when (t) {
        MotionEvent.TOOL_TYPE_FINGER -> "finger"
        MotionEvent.TOOL_TYPE_STYLUS -> "stylus"
        MotionEvent.TOOL_TYPE_ERASER -> "eraser"
        MotionEvent.TOOL_TYPE_MOUSE -> "mouse"
        else -> "unknown$t"
    }

    // ---------- the report ----------

    fun report(dm: android.util.DisplayMetrics, status: String, strict: Int): String {
        val sb = StringBuilder()
        sb.append("STYLUS NOTES REPORT v1 (app 4.1)\n")
        sb.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            .append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("Screen ${dm.widthPixels}x${dm.heightPixels} px, density ${f2(dm.density)}\n")
        sb.append("Strictness $strict\n")
        sb.append("App state: ").append(status.replace("\n", " | ")).append("\n\n")

        // A. what Android says the screen can report
        sb.append("A. INPUT DEVICES (axes the hardware offers)\n")
        try {
            for (id in InputDevice.getDeviceIds()) {
                val d = InputDevice.getDevice(id) ?: continue
                val src = d.sources
                val isTouch = (src and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN
                val isStylus = (src and InputDevice.SOURCE_STYLUS) == InputDevice.SOURCE_STYLUS
                if (!isTouch && !isStylus) continue
                sb.append("  device $id \"${d.name}\" sources 0x${Integer.toHexString(src)}")
                if (isTouch) sb.append(" touchscreen")
                if (isStylus) sb.append(" STYLUS-SOURCE")
                sb.append('\n')
                val parts = ArrayList<String>()
                for (m in d.motionRanges) {
                    parts.add(MotionEvent.axisToString(m.axis) + " " + f2(m.min) + ".." + f2(m.max))
                }
                sb.append("    axes: ").append(parts.joinToString(", ")).append('\n')
            }
        } catch (e: Exception) { sb.append("  could not read: ").append(e.toString()).append('\n') }
        sb.append('\n')

        // B. what actually arrived
        sb.append("B. WHAT ARRIVED IN THE APP\n")
        sb.append("  touch events seen: $events, device ids ${deviceIds.joinToString(",")}\n")
        sb.append("  tool types: ").append(if (toolSeen.isEmpty()) "none" else toolSeen.entries.joinToString(", ") { toolName(it.key) + " " + it.value }).append('\n')
        sb.append("  hover events by tool: ").append(if (hoverSeen.isEmpty()) "none" else hoverSeen.entries.joinToString(", ") { toolName(it.key) + " " + it.value }).append('\n')
        sb.append("  events where an axis was not zero: ").append(if (axisNonZero.isEmpty()) "NONE (the phone reports no size, shape or pressure)" else axisNonZero.entries.joinToString(", ") { it.key + " " + it.value }).append('\n')
        sb.append("  pressure values seen: ").append(pressVals.joinToString(", ")).append("\n\n")

        // C. per kind of learning
        sb.append("C. LEARNING DATA\n")
        val names = mapOf("S" to "stylus only", "F" to "fingers and palm", "N" to "natural writing with hand resting", "U" to "normal use")
        for (lab in arrayOf("S", "F", "N", "U")) {
            var sessN = 0; var cont = 0; var maxc = 0; var canc = 0
            val states = HashMap<String, Int>()
            for (s in sessions) if (s.label == lab) {
                sessN++; cont += s.recs.size; maxc = max(maxc, s.maxConc); if (s.cancelled) canc++
                for (r in s.recs) states[r.state] = (states[r.state] ?: 0) + 1
            }
            sb.append("  ${names[lab]}: $sessN gestures, $cont contacts, most at once $maxc, cancelled gestures $canc")
            if (states.isNotEmpty()) sb.append(", decisions {").append(states.entries.joinToString(", ") { it.key + " " + it.value }).append("}")
            sb.append('\n')
        }
        sb.append('\n')

        // D. measurements per class
        val pen = ArrayList<Rec>(); val handF = ArrayList<Rec>(); val handN = ArrayList<Rec>(); val penN = ArrayList<Rec>()
        for (s in sessions) for (r in s.recs) when (s.label) {
            "S" -> pen.add(r)
            "F" -> handF.add(r)
            "N" -> if (usable(s)) { if (r.isPen) penN.add(r) else handN.add(r) }
        }
        sb.append("D. MEASUREMENTS PER CLASS\n")
        val classes = listOf("stylus only" to pen, "pen in natural writing" to penN, "fingers and palm" to handF, "hand resting while writing" to handN)
        for (k in 0 until Rec.NFEAT) {
            sb.append(Rec.NAMES[k]).append('\n')
            for ((cn, lst) in classes) sb.append(statLine(cn, lst.map { it.f[k] })).append('\n')
        }
        sb.append('\n')

        // E. best single measurement
        sb.append("E. BEST SINGLE MEASUREMENT (balanced accuracy, 100% = perfect)\n")
        sb.append(" shape and size only (stylus only + natural pen  vs  fingers + palm + resting hand):\n")
        val penAll = pen + penN
        val handAll = handF + handN
        for (k in 0 until Rec.NSTATIC) {
            val (t, a) = split(penAll.map { it.f[k] }, handAll.map { it.f[k] })
            sb.append("  ${Rec.NAMES[k]}: $t, accuracy ${if (a < 0) "n/a" else f1(a * 100f) + "%"}\n")
        }
        sb.append(" movement (natural writing only: the pen versus the resting hand that touched at the same time):\n")
        for (k in Rec.NSTATIC until Rec.NFEAT) {
            val (t, a) = split(penN.map { it.f[k] }, handN.map { it.f[k] })
            sb.append("  ${Rec.NAMES[k]}: $t, accuracy ${if (a < 0) "n/a" else f1(a * 100f) + "%"}\n")
        }
        sb.append('\n')

        // F. position rules replay
        sb.append("F. WHICH RULE PICKS THE PEN (replay of natural writing gestures)\n")
        val use = usableNatural()
        val hm = buildHandModel(null)
        if (hm != null) sb.append("  hand model: the resting hand lands ${f1(hm.mx)} dp across and ${f1(hm.my)} dp down from the pen tip (spread ${f1(hm.sx)} x ${f1(hm.sy)}), from ${hm.n} contacts\n")
        else sb.append("  hand model: not learned (needs at least 5 hand contacts from step 3)\n")
        if (use.isEmpty()) sb.append("  no usable natural writing gestures yet: do step 3 (write naturally with your hand resting)\n")
        else {
            var top = 0; var bottom = 0; var first = 0; var last = 0; var model = 0; var modelN = 0
            for (s in use) {
                val penIdx = s.recs.indexOfFirst { it.isPen }
                var t = 0; var b = 0; var fi = 0; var la = 0
                for (i in s.recs.indices) {
                    if (s.recs[i].y0 < s.recs[t].y0) t = i
                    if (s.recs[i].y0 > s.recs[b].y0) b = i
                    if (s.recs[i].t0 < s.recs[fi].t0) fi = i
                    if (s.recs[i].t0 > s.recs[la].t0) la = i
                }
                if (t == penIdx) top++
                if (b == penIdx) bottom++
                if (fi == penIdx) first++
                if (la == penIdx) last++
                val m = buildHandModel(s)
                if (m != null) {
                    modelN++
                    var bi = 0; var bc = Float.MAX_VALUE
                    for (i in s.recs.indices) {
                        var c = 0f
                        for (j in s.recs.indices) if (j != i) c += m.cost(s.recs[j].x0 - s.recs[i].x0, s.recs[j].y0 - s.recs[i].y0)
                        if (c < bc) { bc = c; bi = i }
                    }
                    if (bi == penIdx) model++
                }
            }
            val n = use.size
            sb.append("  gestures tested: $n\n")
            sb.append("  topmost contact is the pen: $top/$n\n")
            sb.append("  lowest contact is the pen: $bottom/$n\n")
            sb.append("  first to land is the pen: $first/$n\n")
            sb.append("  last to land is the pen: $last/$n\n")
            sb.append("  hand model (tested on gestures it did not learn from): $model/$modelN\n")
        }
        sb.append('\n')

        // G. recent contacts
        sb.append("G. RECENT CONTACTS (g=gesture, tool, kind, how many at once, landing order, pos dp, size/minor/pressure/round, path dp, speed dp/s, turn deg, ms, decision)\n")
        var gi = 0
        val show = ArrayList<String>()
        for (s in sessions) {
            gi++
            for (r in s.recs) {
                show.add("g$gi ${toolName(r.tool)} ${s.label} c${r.conc} #${r.order} (${f1(r.x0)},${f1(r.y0)}) " +
                    "sz${f1(r.f[0])} mn${f1(r.f[1])} pr${f1(r.f[2])} rd${f1(r.f[4])} path${f1(r.f[6])} sp${f1(r.f[7])} tn${f1(r.f[9])} ${r.dur}ms " +
                    (if (r.isPen) "PEN " else "") + r.state + (if (r.cancelled) " CANCELLED" else "") + (if (r.why.isNotEmpty()) " [" + r.why + "]" else ""))
            }
        }
        val from = max(0, show.size - 150)
        for (i in from until show.size) sb.append("  ").append(show[i]).append('\n')
        sb.append('\n')

        // H. conclusions
        sb.append("H. CONCLUSIONS\n")
        val sizeSeen = axisNonZero["touchMajor"] ?: 0
        val sizeSeen2 = axisNonZero["size"] ?: 0
        if (events == 0) sb.append("  - No touches recorded yet: do the learn steps first, then make this report.\n")
        else {
            if (sizeSeen == 0 && sizeSeen2 == 0) sb.append("  - This phone gives the app NO contact size: shape rules cannot work, only position, timing and movement.\n")
            else sb.append("  - The phone does report contact size, so the shape fingerprint can work.\n")
            if ((toolSeen[MotionEvent.TOOL_TYPE_STYLUS] ?: 0) > 0) sb.append("  - The stylus reports itself as a stylus: the app can lock to that.\n")
            else sb.append("  - The stylus looks like a finger to Android (passive stylus).\n")
            var bestName = ""; var bestAcc = 0f
            for (k in 0 until Rec.NFEAT) {
                val lst = if (k < Rec.NSTATIC) Pair(penAll, handAll) else Pair(penN, handN)
                val (_, a) = split(lst.first.map { it.f[k] }, lst.second.map { it.f[k] })
                if (a > bestAcc) { bestAcc = a; bestName = Rec.NAMES[k] }
            }
            if (bestName.isNotEmpty()) sb.append("  - Best single measurement: $bestName (${f1(bestAcc * 100f)}%).\n")
        }
        return sb.toString()
    }
}
