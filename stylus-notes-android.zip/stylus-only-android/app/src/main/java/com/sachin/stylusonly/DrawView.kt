package com.sachin.stylusonly

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private const val NF = 6   // measured values per touch: size, minor axis, pressure, area, roundness, steadiness

class DrawView(
    ctx: Context,
    private val cfg: Cfg,
    private val hud: (String, Boolean) -> Unit,
    private val toast: (String) -> Unit,
    private val onStatus: () -> Unit,
    private val onChanged: () -> Unit,
    private val writing: (Boolean) -> Unit
) : View(ctx) {

    private class Ptr(val id: Int, val tool: Int, val downT: Long) {
        var state = PEND
        var size = 0f
        var x = 0f
        var y = 0f
        val pts = ArrayList<PointF>()   // page coordinates, buffered until we decide
        var why: String? = null
        var seen = 0
        var n = 0
        val first = FloatArray(NF)
        val sum = FloatArray(NF)
        var sq = 0f
        /** the first reading of a touch is often half formed, so it is skipped in the average */
        fun add(f: FloatArray) {
            if (seen == 0) { for (k in 0 until NF) first[k] = f[k] }
            else { for (k in 0 until 5) sum[k] += f[k]; sq += f[0] * f[0]; n++ }
            seen++
        }
        fun mean(k: Int): Float {
            if (k == 5) {      // steadiness: how much the contact size wobbles (a finger wobbles, a pen tip does not)
                if (n < 2) return 0f
                val m = sum[0] / n
                val v = sq / n - m * m
                return if (v > 0f) sqrt(v) else 0f
            }
            return if (n > 0) sum[k] / n else first[k]
        }
    }

    private companion object {
        const val PEND = 0      // just landed, deciding what it is
        const val CAND = 1      // looks like the stylus (temporary label)
        const val WRITER = 2    // the one contact that is writing
        const val FINGER = 3    // finger-sized: ignored
        const val PALM = 4      // palm-sized: ignored completely
        const val IGN = 5       // anything else: ignored
        const val MIN_Z = 0.25f // zoom limits (times screen density)
        const val MAX_Z = 6f
        const val A4W = 595f    // A4 page in units (points)
        const val A4H = 842f
        const val GAP = 10f     // desk between two pages
        const val DESK = 0xFFC9CED6.toInt()
    }

    private val dp = resources.displayMetrics.density
    private val strokes = ArrayList<Stroke>()
    private val redoStack = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private val ptrs = LinkedHashMap<Int, Ptr>()
    private var writerId = -1
    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false
    private val decideRun = Runnable { scheduled = false; decide() }

    var note: Note = Note("", "", 0L, 0L, MODE_A4, 1)
    private var docMode = MODE_A4
    private var pages = 1
    private var needView = false

    // view: screen = page * z + t
    private var tx = 0f
    private var ty = 0f
    private var z = 1f
    private var lastWriteEnd = 0L
    private var panWriter = false
    private var wasWriting = false

    // auto move at the edge
    private var edgeOn = false
    private var zoneSince = 0L
    private var lastTick = 0L
    private val ev = FloatArray(2)
    private val edgeRun = Runnable { edgeTick() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pagePaint = Paint().apply { style = Paint.Style.FILL }
    private val indPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x66000000 }
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private val vis = RectF()
    private val exRects = ArrayList<Rect>()

    var eraser = false
    var hand = false
    var color = Color.BLACK
    var calibrating: String? = null
    var blockGestures = true
        set(v) { field = v; applyExclusion() }

    private var mode = "none"   // none = not learned, size = match by contact fingerprint, pos = phone reports no size
    private var toolOnly = false // phone sends a real pen signal: only that can draw
    private var smin = 0f
    private var smax = 0f
    private var fmin = 0f
    private val sLo = FloatArray(NF)      // learned stylus fingerprint: lowest and highest value of each measurement
    private val sHi = FloatArray(NF)
    private val fnames = arrayOf("size", "minor", "pressure", "area", "roundness", "steadiness")
    private val calSF = ArrayList<FloatArray>()
    private val calFF = ArrayList<FloatArray>()
    private var calToolN = 0
    private var calToolHits = 0
    private val tmp = FloatArray(NF)
    private val prefs = cfg.prefs

    init {
        mode = prefs.getString("mode", "none") ?: "none"
        toolOnly = prefs.getBoolean("toolOnly", false)
        smin = prefs.getFloat("smin", 0f); smax = prefs.getFloat("smax", 0f); fmin = prefs.getFloat("fmin", 0f)
        val lo = prefs.getString("fpLo", "")?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: emptyList()
        val hi = prefs.getString("fpHi", "")?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: emptyList()
        if (lo.size == NF && hi.size == NF) {
            for (k in 0 until NF) { sLo[k] = lo[k]; sHi[k] = hi[k] }
        } else if (smax > 0f) {      // learned with an older version: only the size is known
            sLo[0] = smin; sHi[0] = smax
        }
        reloadCal()
    }

    // ---------- document ----------

    fun loadNote(n: Note) {
        cancelAll()
        note = n
        strokes.clear(); strokes.addAll(n.strokes); redoStack.clear()
        docMode = n.mode; pages = max(1, n.pages)
        if (docMode == MODE_A4) {
            var maxY = 0f
            for (s in strokes) for (p in s.pts) if (p.y > maxY) maxY = p.y
            while (pages < 500 && contentH() < maxY) pages++
        }
        needView = true
        if (width > 0) applyOpenView()
        invalidate()
    }

    /** a copy of the page that is safe to write to disk on another thread (finished strokes never change) */
    fun snapshot(): Note {
        val n = Note(note.id, note.title, note.created, System.currentTimeMillis(), docMode, pages)
        n.zf = z / dp; n.vx = -tx / z; n.vy = -ty / z
        n.strokes.addAll(strokes)
        n.strokeCount = strokes.size
        note.modified = n.modified
        return n
    }

    fun isA4() = docMode == MODE_A4
    fun pageCount() = pages
    fun isWritingNow() = writerId != -1

    private fun contentH(): Float = pages * A4H + (pages - 1) * GAP
    private fun pageTop(i: Int): Float = i * (A4H + GAP)

    fun currentPage(): Int {
        if (docMode != MODE_A4) return 1
        val yMid = (height / 2f - ty) / z
        return (floor(yMid / (A4H + GAP)).toInt() + 1).coerceIn(1, pages)
    }

    fun addPage() {
        if (docMode == MODE_A4 && pages < 500) { pages++; clampView(); invalidate(); onChanged() }
    }

    // ---------- view: fit, zoom, move ----------

    private fun clampView() {
        if (width == 0 || height == 0) return
        if (docMode == MODE_A4) {
            val cw = A4W * z; val ch = contentH() * z; val m = 12f * dp
            tx = if (cw + 2 * m <= width) (width - cw) / 2f else tx.coerceIn(width - cw - m, m)
            ty = if (ch + 2 * m <= height) m else ty.coerceIn(height - ch - m, m)
        } else {
            tx = tx.coerceIn(-2_000_000f, 2_000_000f); ty = ty.coerceIn(-2_000_000f, 2_000_000f)
        }
    }

    private fun applyOpenView() {
        needView = false
        if (docMode == MODE_A4) {
            z = ((width - 24f * dp) / A4W).coerceIn(MIN_Z * dp, MAX_Z * dp)
            tx = (width - A4W * z) / 2f
            ty = if (note.vy == 0f && note.vx == 0f) 12f * dp else -note.vy * z
        } else {
            z = note.zf.coerceIn(MIN_Z, MAX_Z) * dp
            tx = -note.vx * z; ty = -note.vy * z
        }
        clampView()
    }

    /** A4: page fills the width. Unlimited: one unit = one dp */
    fun fit() {
        if (width == 0) return
        val cy0 = -ty / z
        if (docMode == MODE_A4) {
            z = ((width - 24f * dp) / A4W).coerceIn(MIN_Z * dp, MAX_Z * dp)
            tx = (width - A4W * z) / 2f; ty = -cy0 * z
        } else {
            val cx0 = -tx / z
            z = dp; tx = -cx0 * z; ty = -cy0 * z
        }
        clampView(); invalidate()
    }

    fun zoomBy(f: Float) {
        val nz = (z * f).coerceIn(MIN_Z * dp, MAX_Z * dp)
        val k = nz / z
        val fx = width / 2f; val fy = height / 2f
        tx = fx - (fx - tx) * k; ty = fy - (fy - ty) * k; z = nz
        clampView(); invalidate()
    }

    /** move the page by this many screen pixels (dx right, dy down shows later parts of the page) */
    fun scrollBy(dx: Float, dy: Float) { tx -= dx; ty -= dy; clampView(); invalidate() }

    fun pageStep(dir: Int) { scrollBy(0f, dir * height * 0.85f) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (needView && w > 0 && h > 0) applyOpenView() else clampView()
        applyExclusion()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        applyExclusion()
    }

    /** asks Android not to treat swipes from the screen edges as Back or Home gestures while writing */
    private fun applyExclusion() {
        if (Build.VERSION.SDK_INT >= 29) {
            exRects.clear()
            if (blockGestures && width > 0 && height > 0) exRects.add(Rect(0, 0, width, height))
            systemGestureExclusionRects = exRects
        }
    }

    // ---------- learned stylus fingerprint ----------

    private fun hiLoose(): Float {
        var h = smax * 1.25f
        if (fmin > smax) h = min(h, (smax + fmin) / 2f)
        return h
    }

    private fun loB(): Float = smin * 0.6f

    private fun palmThr(): Float =
        if (fmin > 0f) max(fmin * 1.7f, hiLoose() * 1.8f) else hiLoose() * 2.2f

    private fun fmt(v: Float): String = "%.2f".format(v)

    fun statusText(): String {
        if (mode == "pos") return "This phone reports no touch size. Only the position rule works."
        if (mode != "size" && !toolOnly) return "Not learned yet. Use Learn stylus."
        val sb = StringBuilder()
        if (toolOnly) sb.append("Real pen signal found: ONLY the pen can draw. Fingers and palms never draw.\n")
        if (mode == "size") {
            sb.append("Stylus fingerprint learned:")
            for (k in 0 until NF) if (sHi[k] > 0f) sb.append("\n  ").append(fnames[k]).append(" ").append(fmt(sLo[k])).append(" to ").append(fmt(sHi[k]))
        }
        return sb.toString()
    }

    private fun parseCal(key: String, out: ArrayList<FloatArray>) {
        out.clear()
        val txt = prefs.getString(key, "") ?: ""
        for (row in txt.split(";")) {
            val v = row.split(",").mapNotNull { it.toFloatOrNull() }
            if (v.size == NF) out.add(v.toFloatArray())
        }
    }

    private fun saveCal() {
        prefs.edit()
            .putString("SF", calSF.joinToString(";") { it.joinToString(",") })
            .putString("FF", calFF.joinToString(";") { it.joinToString(",") })
            .apply()
    }

    private fun reloadCal() { parseCal("SF", calSF); parseCal("FF", calFF) }

    /** how far a touch's measurements may stray from the learned stylus fingerprint; f makes it tighter or looser */
    private fun whyNot(p: Ptr, f: Float): String? {
        val m = (0.1f + (100 - cfg.strict) / 100f * 0.9f) * f
        for (k in 0 until NF) {
            if (sHi[k] <= 0f) continue
            if (k == 5 && p.n < 8) continue      // too short a touch to judge steadiness
            val v = p.mean(k)
            val tol = (sHi[k] - sLo[k]) * m + abs((sHi[k] + sLo[k]) / 2f) * 0.03f * f
            if (v < sLo[k] - tol || v > sHi[k] + tol)
                return fnames[k] + " " + fmt(v) + ", stylus is " + fmt(sLo[k]) + " to " + fmt(sHi[k])
        }
        return null
    }

    private fun desc(p: Ptr): String =
        "size " + fmt(p.mean(0)) + " minor " + fmt(p.mean(1)) + " pressure " + fmt(p.mean(2)) + " round " + fmt(p.mean(4))

    private fun feat(e: MotionEvent, i: Int, out: FloatArray) {
        val mj = e.getTouchMajor(i)
        val mn = e.getTouchMinor(i)
        out[0] = if (mj > 0f) mj else e.getSize(i) * 1000f
        out[1] = mn
        out[2] = e.getPressure(i) * 100f
        out[3] = e.getSize(i) * 1000f
        out[4] = if (mj > 0f && mn > 0f) mn / mj * 100f else 0f
        out[5] = 0f
    }

    private fun recordCal(p: Ptr) {
        val k = calibrating ?: return
        if (p.seen < 3) return
        if (k == "stylus" && p.state != WRITER) return
        val v = FloatArray(NF)
        for (j in 0 until NF) v[j] = p.mean(j)
        if (k == "stylus") { calToolN++; if (isStylusTool(p.tool)) calToolHits++ }
        (if (k == "stylus") calSF else calFF).add(v)
    }

    private fun sizeOf(e: MotionEvent, i: Int): Float {
        val m = e.getTouchMajor(i)
        return if (m > 0f) m else e.getSize(i) * 1000f
    }

    private fun isStylusTool(t: Int) = t == MotionEvent.TOOL_TYPE_STYLUS || t == MotionEvent.TOOL_TYPE_ERASER

    private fun cx(x: Float): Float {
        val v = (x - tx) / z
        return if (docMode == MODE_A4) v.coerceIn(0f, A4W) else v
    }

    private fun cy(y: Float): Float {
        val v = (y - ty) / z
        return if (docMode == MODE_A4) v.coerceIn(0f, contentH()) else v
    }

    // ---------- touch handling ----------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(decideRun); scheduled = false
                if (cur != null) finishStroke(null)
                ptrs.clear(); writerId = -1; panWriter = false
                requestUnbufferedDispatch(e)
                addPtr(e, 0)
            }
            MotionEvent.ACTION_POINTER_DOWN -> addPtr(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> onMove(e)
            MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_UP -> {
                up(e.getPointerId(e.actionIndex))
                ptrs.clear(); writerId = -1; panWriter = false
                notifyWriting(false)
            }
            MotionEvent.ACTION_CANCEL -> cancelAll()   // keeps whatever was already written
        }
        return true
    }

    private fun notifyWriting(b: Boolean) {
        if (wasWriting != b) { wasWriting = b; writing(b) }
    }

    private fun addPts(list: ArrayList<PointF>, e: MotionEvent, i: Int) {
        for (h in 0 until e.historySize) list.add(PointF(cx(e.getHistoricalX(i, h)), cy(e.getHistoricalY(i, h))))
        list.add(PointF(cx(e.getX(i)), cy(e.getY(i))))
    }

    private fun addPtr(e: MotionEvent, i: Int) {
        val id = e.getPointerId(i)
        val p = Ptr(id, e.getToolType(i), SystemClock.uptimeMillis())
        p.size = sizeOf(e, i); p.x = e.getX(i); p.y = e.getY(i)
        p.pts.add(PointF(cx(p.x), cy(p.y)))
        feat(e, i, tmp); p.add(tmp)
        ptrs[id] = p
        if (isStylusTool(p.tool) && ptrs.size == 1 && calibrating == null) {
            decide()   // phone says it is the stylus and nothing else touches: no delay
        } else if (!scheduled) {
            scheduled = true; handler.postDelayed(decideRun, 40)
        }
    }

    private fun onMove(e: MotionEvent) {
        for (i in 0 until e.pointerCount) {
            val p = ptrs[e.getPointerId(i)] ?: continue
            val sz = sizeOf(e, i)
            val ox = p.x; val oy = p.y
            p.x = e.getX(i); p.y = e.getY(i)
            if (sz > p.size) p.size = sz
            feat(e, i, tmp); p.add(tmp)
            when (p.state) {
                PEND -> addPts(p.pts, e, i)
                WRITER -> {
                    if (panWriter && p.id == writerId) {
                        tx += p.x - ox; ty += p.y - oy; clampView()      // Hand tool: the pen drags the page
                    } else {
                        val c = cur
                        if (c != null && p.id == writerId) {
                            addPts(c.pts, e, i)
                            // a contact that suddenly becomes huge was a palm landing, not the stylus
                            if (calibrating == null && mode == "size" && !isStylusTool(p.tool) && p.n >= 10 && whyNot(p, 1.4f) != null) {
                                p.state = IGN; cur = null; writerId = -1; notifyWriting(false)
                                hud("stopped: this contact is not the stylus", false)
                            } else if (calibrating == null && mode == "size" && !isStylusTool(p.tool) && sz > palmThr()) {
                                p.state = PALM; cur = null; writerId = -1; notifyWriting(false)
                                hud("big contact (palm), dropped", false)
                            } else startEdge()
                        }
                    }
                }
                FINGER -> if (mode == "size" && p.size > palmThr()) p.state = PALM
            }
        }
        invalidate()
    }

    private fun up(id: Int) {
        val p = ptrs[id] ?: return
        if (p.state == PEND) { handler.removeCallbacks(decideRun); scheduled = false; decide() }
        if (calibrating != null) recordCal(p)
        if (p.state == WRITER && id == writerId) finishStroke(p)
        ptrs.remove(id)
    }

    private fun cancelAll() {
        handler.removeCallbacks(decideRun); scheduled = false
        handler.removeCallbacks(edgeRun); edgeOn = false
        val w = ptrs[writerId]
        if (cur != null) finishStroke(w)
        ptrs.clear(); writerId = -1; cur = null; panWriter = false
        notifyWriting(false)
        invalidate()
    }

    private fun classify(p: Ptr, palmNear: Boolean): Int {
        if (isStylusTool(p.tool)) return CAND
        if (toolOnly) return if (mode == "size" && p.size > palmThr()) PALM else FINGER   // the pen always announces itself
        if (mode == "pos") return CAND
        if (mode != "size") return FINGER
        if (p.size > palmThr()) return PALM
        if (p.size < loB()) return IGN
        // the stylus has its own fingerprint (size, shape, pressure, steadiness); a finger of the same size still differs in the others
        val w = whyNot(p, if (palmNear) 1.5f else 1f)
        p.why = w
        return if (w == null) CAND else FINGER
    }

    private fun decide() {
        val pend = ArrayList<Ptr>()
        for (p in ptrs.values) if (p.state == PEND) pend.add(p)
        if (pend.isEmpty()) return
        val cal = calibrating

        var palmNear = false
        if (mode == "size") for (p in ptrs.values) if (p.state == PALM || (p.state == PEND && p.size > palmThr())) palmNear = true

        val cands = ArrayList<Ptr>()
        for (p in pend) {
            val c = if (cal != null) CAND else classify(p, palmNear)
            if (c == CAND) cands.add(p) else {
                p.state = c
                hud(when {
                    mode == "none" && !toolOnly -> "not learned yet. " + desc(p)
                    c == PALM -> "palm. " + desc(p)
                    toolOnly -> "finger, no pen signal. " + desc(p)
                    else -> "not stylus: " + (p.why ?: desc(p))
                }, false)
            }
        }
        if (cands.isEmpty()) return

        val old = ptrs[writerId]
        if (writerId != -1 && old != null) {
            // already writing: a second contact never steals the pen, except a real stylus replacing a finger-type one
            val real = cands.firstOrNull { isStylusTool(it.tool) }
            if (real != null && !isStylusTool(old.tool)) {
                old.state = IGN; cur = null; writerId = -1
                for (p in cands) if (p !== real) p.state = IGN
                startWriter(real)
            } else {
                for (p in cands) p.state = IGN
                hud("second contact ignored", false)
            }
            return
        }
        val w = cands.firstOrNull { isStylusTool(it.tool) }
            ?: if (cands.all { it.size > 0f }) cands.minByOrNull { it.size }!! else cands.minByOrNull { it.pts[0].y }!!
        for (p in cands) if (p !== w) p.state = IGN
        startWriter(w)
    }

    private fun startWriter(w: Ptr) {
        w.state = WRITER; writerId = w.id
        notifyWriting(true)
        if (hand && calibrating == null) {
            panWriter = true; cur = null
            hud("hand: moving the page", true)
            return
        }
        panWriter = false
        val er = eraser || w.tool == MotionEvent.TOOL_TYPE_ERASER
        val width = if (er) cfg.eraser.toFloat() else cfg.penU()
        val s = Stroke(color, width, er, calibrating != null)
        s.pts.addAll(w.pts)
        cur = s
        hud(desc(w), true)
        invalidate()
    }

    private fun finishStroke(p: Ptr?) {
        val c = cur
        cur = null; writerId = -1; panWriter = false
        lastWriteEnd = SystemClock.uptimeMillis()
        notifyWriting(false)
        if (c == null) return
        c.done = true
        if (!c.cal) {
            if (p != null && isFingerDot(c, p)) hud("tap from a finger ignored", false)
            else { strokes.add(c); redoStack.clear(); onChanged() }
        }
        invalidate()
    }

    /** a lone tap that is bigger than any stylus tap you taught is a fingertip, not a dot */
    private fun isFingerDot(c: Stroke, p: Ptr): Boolean {
        if (mode != "size" || isStylusTool(p.tool) || c.pts.isEmpty()) return false
        val a = c.pts[0]
        var far = 0f
        for (q in c.pts) far = max(far, hypot(q.x - a.x, q.y - a.y))
        if (far >= 2.5f * dp / z) return false
        if (!cfg.dots) return true                 // dots from taps switched off in Settings
        return whyNot(p, 0.5f) != null             // a dot must match the stylus fingerprint very closely
    }

    // ---------- automatic move when the pen reaches the edge (like Excel) ----------

    private fun startEdge() {
        if (!edgeOn && cfg.autoScroll && calibrating == null && cur != null) {
            edgeOn = true
            handler.postDelayed(edgeRun, 16)
        }
    }

    private fun edgeTick() {
        edgeOn = false
        val w = ptrs[writerId] ?: return
        val c = cur ?: return
        if (!cfg.autoScroll || panWriter) return
        val zn = max(24f, cfg.edgeZone.toFloat()) * dp
        ev[0] = 0f; ev[1] = 0f
        if (w.x < zn) ev[0] = -(zn - w.x) / zn else if (w.x > width - zn) ev[0] = (w.x - (width - zn)) / zn
        if (w.y < zn) ev[1] = -(zn - w.y) / zn else if (w.y > height - zn) ev[1] = (w.y - (height - zn)) / zn
        val now = SystemClock.uptimeMillis()
        if (ev[0] == 0f && ev[1] == 0f) { zoneSince = 0L; return }     // the next pen move starts the check again
        if (zoneSince == 0L) { zoneSince = now; lastTick = now }
        edgeOn = true
        handler.postDelayed(edgeRun, 16)
        if (now - zoneSince < 300L) return                             // short wait, so normal writing near the edge does not jump
        val dt = ((now - lastTick).coerceIn(1L, 50L)) / 1000f
        lastTick = now
        val sp = cfg.scrollSpeed.coerceIn(1, 15) * 90f * dp
        val ox = tx; val oy = ty
        tx -= ev[0] * sp * dt; ty -= ev[1] * sp * dt
        clampView()
        if (docMode == MODE_A4 && cfg.autoPage && ev[1] > 0.3f && ty == oy) addPage()   // reached the end of the last page
        if (tx != ox || ty != oy) {
            c.pts.add(PointF(cx(w.x), cy(w.y)))     // pen stays still on the glass, the paper slides under it: the line keeps growing
            invalidate()
        }
    }

    // ---------- learning ----------

    fun startLearn(kind: String) {
        cancelAll()
        calibrating = kind
        if (kind == "stylus") { calSF.clear(); calToolN = 0; calToolHits = 0 } else calFF.clear()
        toast(if (kind == "stylus") "Draw 8 or more short separate lines with ONLY the stylus (change angle and pressure a little), then tap Done"
              else "Touch the screen 8 or more times with your fingers and palm (one, two, whole hand), then tap Done")
    }

    fun finishLearn() {
        cancelAll()
        val k = calibrating
        calibrating = null
        if (k != null) learn(k)
        invalidate()
    }

    fun abortLearn() { cancelAll(); calibrating = null; reloadCal(); invalidate() }

    fun resetLearning() {
        mode = "none"; toolOnly = false; smin = 0f; smax = 0f; fmin = 0f; calSF.clear(); calFF.clear()
        for (k in 0 until NF) { sLo[k] = 0f; sHi[k] = 0f }
        prefs.edit().remove("mode").remove("toolOnly").remove("smin").remove("smax").remove("fmin").remove("SF").remove("FF").remove("fpLo").remove("fpHi").apply()
        onStatus()
    }

    private fun learn(kind: String) {
        saveCal()
        if (calSF.size < 4) { toast("Draw at least 4 separate lines with the stylus first (8 is better)"); return }
        if (kind == "stylus") {
            // does the phone announce the pen as a pen? Then that signal is the most unique identity there is.
            toolOnly = calToolN >= 4 && calToolHits >= calToolN * 0.7f
            prefs.edit().putBoolean("toolOnly", toolOnly).apply()
        }
        // drop a stray palm that got into the stylus samples
        val sizes = calSF.map { it[0] }.sorted()
        val med = sizes[sizes.size / 2]
        val rows = calSF.filter { it[0] <= med * 1.6f }
        if (med <= 0f) {
            mode = "pos"; prefs.edit().putString("mode", mode).apply(); onStatus()
            toast(if (toolOnly) "Your pen sends a real pen signal, so only the pen can draw." else "This phone reports no touch size, so it cannot tell a finger from the stylus. Only the position rule is active.")
            return
        }
        for (k in 0 until NF) {
            var v = rows.map { it[k] }.sorted()
            if (v.size >= 12) v = v.subList(1, v.size - 1)
            sLo[k] = v.first(); sHi[k] = v.last()
        }
        smin = sLo[0]; smax = sHi[0]
        val f = calFF.map { it[0] }.sorted()
        fmin = if (f.size >= 3) f[f.size / 5] else 0f
        var best = -1
        var bestOv = 2f
        if (calFF.size >= 3) for (k in 0 until NF) {
            if (sHi[k] <= 0f) continue
            var inside = 0
            for (r in calFF) if (r[k] >= sLo[k] * 0.9f && r[k] <= sHi[k] * 1.1f) inside++
            val ov = inside / calFF.size.toFloat()
            if (ov < bestOv) { bestOv = ov; best = k }
        }
        var msg = "Stylus fingerprint learned from ${rows.size} lines."
        if (toolOnly) msg += " Your pen sends a real pen signal: now ONLY the pen can draw."
        else if (calFF.size < 3) msg += " Now do Learn fingers too: it lets the app check how well fingers are told apart."
        else if (best >= 0 && bestOv > 0.5f) msg += " Warning: your fingers look like the stylus in every measurement this phone gives. Turn off Allow dots and keep strictness high."
        else if (best >= 0) msg += " Best at telling fingers apart: ${fnames[best]}."
        mode = "size"
        prefs.edit().putString("mode", mode).putFloat("smin", smin).putFloat("smax", smax).putFloat("fmin", fmin)
            .putString("fpLo", sLo.joinToString(",")).putString("fpHi", sHi.joinToString(",")).apply()
        onStatus(); toast(msg)
    }

    // ---------- undo, clear ----------

    fun undo() { if (strokes.isNotEmpty()) { redoStack.add(strokes.removeAt(strokes.size - 1)); invalidate(); onChanged() } }
    fun redo() { if (redoStack.isNotEmpty()) { strokes.add(redoStack.removeAt(redoStack.size - 1)); invalidate(); onChanged() } }
    fun clearAll() { strokes.clear(); redoStack.clear(); invalidate(); onChanged() }

    // ---------- drawing ----------

    private fun buildPath(p: List<PointF>): Path {
        val path = Path()
        if (p.isEmpty()) return path
        path.moveTo(p[0].x, p[0].y)
        if (p.size == 1) { path.lineTo(p[0].x + 0.1f, p[0].y); return path }
        for (i in 1 until p.size - 1) path.quadTo(p[i].x, p[i].y, (p[i].x + p[i + 1].x) / 2, (p[i].y + p[i + 1].y) / 2)
        path.lineTo(p.last().x, p.last().y)
        return path
    }

    private fun boundsOf(s: Stroke): RectF {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (p in s.pts) { l = min(l, p.x); t = min(t, p.y); r = max(r, p.x); b = max(b, p.y) }
        val pad = s.width
        return RectF(l - pad, t - pad, r + pad, b + pad)
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        var path = s.path
        if (path == null || s.pathN != s.pts.size) {
            path = buildPath(s.pts); s.path = path; s.pathN = s.pts.size
        }
        if (s.eraser) { paint.xfermode = clearMode; paint.color = Color.BLACK }
        else { paint.xfermode = null; paint.color = s.color }
        paint.strokeWidth = s.width
        c.drawPath(path, paint)
        paint.xfermode = null
    }

    /** ruled lines, grid or dots inside the rectangle x0,y0 - x1,y1. Rows start at oy, and nothing is drawn above lim. */
    private fun drawPattern(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, oy: Float, lim: Float, s: Float) {
        val style = cfg.paper
        if (style == 0 || x1 <= x0 || y1 <= y0) return
        val sp = max(8f, cfg.spacing.toFloat())
        gp.color = Cfg.LINE[cfg.lineColor.coerceIn(0, Cfg.LINE.size - 1)]
        gp.strokeWidth = max(1f, 0.6f * dp) / s
        gp.strokeCap = Paint.Cap.BUTT
        val ys = max(y0, lim)
        if (ys >= y1) return
        if (style == 1 || style == 2) {
            var k = ceil((ys - oy) / sp).toInt()
            var y = oy + k * sp
            var n = 0
            while (y <= y1 && n < 800) { c.drawLine(x0, y, x1, y, gp); k++; y = oy + k * sp; n++ }
        }
        if (style == 2) {
            var kx = ceil(x0 / sp).toInt()
            var x = kx * sp
            var n = 0
            while (x <= x1 && n < 800) { c.drawLine(x, ys, x, y1, gp); kx++; x = kx * sp; n++ }
        }
        if (style == 3) {
            val k0 = ceil((ys - oy) / sp).toInt()
            val kx0 = ceil(x0 / sp).toInt()
            val cols = floor(x1 / sp).toInt() - kx0 + 1
            val rows = floor((y1 - oy) / sp).toInt() - k0 + 1
            if (cols > 0 && rows > 0 && cols.toLong() * rows <= 20000L) {
                val arr = FloatArray(cols * rows * 2)
                var i = 0
                for (jy in 0 until rows) for (jx in 0 until cols) {
                    arr[i++] = (kx0 + jx) * sp; arr[i++] = oy + (k0 + jy) * sp
                }
                gp.strokeCap = Paint.Cap.ROUND
                gp.strokeWidth = 2.6f * dp / s
                c.drawPoints(arr, 0, i, gp)
                gp.strokeCap = Paint.Cap.BUTT
            }
        }
    }

    /** paper and ink of the visible part l,t - r,b (page units). s = screen pixels per unit. Used by the screen and the list pictures. */
    private fun renderDoc(c: Canvas, l: Float, t: Float, r: Float, b: Float, s: Float) {
        pagePaint.color = Cfg.PAPER[cfg.paperColor.coerceIn(0, Cfg.PAPER.size - 1)]
        if (docMode == MODE_A4) {
            for (i in 0 until pages) {
                val top = pageTop(i)
                if (top + A4H < t || top > b) continue
                c.drawRect(0f, top, A4W, top + A4H, pagePaint)
                val x0 = max(l, 0f); val x1 = min(r, A4W)
                val y0 = max(t, top); val y1 = min(b, top + A4H)
                drawPattern(c, x0, y0, x1, y1, top + cfg.topMargin, top + cfg.topMargin, s)
                if (cfg.leftMargin) {
                    val mx = cfg.leftMarginPos.toFloat()
                    if (mx in x0..x1 && y1 > y0) {
                        gp.color = Cfg.MARGIN; gp.strokeWidth = max(1f, 0.8f * dp) / s; gp.strokeCap = Paint.Cap.BUTT
                        c.drawLine(mx, y0, mx, y1, gp)
                    }
                }
            }
        } else {
            c.drawRect(l, t, r, b, pagePaint)
            drawPattern(c, l, t, r, b, 0f, -1e9f, s)
        }
        // ink lives in its own layer so the eraser removes ink but never the notebook lines
        vis.set(l, t, r, b)
        val layer = c.saveLayer(l, t, r, b, null)
        for (st in strokes) {
            var bd = st.bounds
            if (bd == null) { bd = boundsOf(st); st.bounds = bd }
            if (RectF.intersects(vis, bd)) drawStroke(c, st)
        }
        cur?.let { drawStroke(c, it) }
        c.restoreToCount(layer)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(if (docMode == MODE_A4) DESK else Cfg.PAPER[cfg.paperColor.coerceIn(0, Cfg.PAPER.size - 1)])
        val l = -tx / z; val t = -ty / z
        val r = (width - tx) / z; val b = (height - ty) / z
        c.save()
        c.translate(tx, ty); c.scale(z, z)
        renderDoc(c, l, t, r, b, z)
        c.restore()
        drawIndicator(c)
    }

    /** thin bar at the right edge shows where you are on a tall A4 note (display only) */
    private fun drawIndicator(c: Canvas) {
        if (docMode != MODE_A4) return
        val total = contentH() * z + 24f * dp
        if (total <= height) return
        val track = height - 16f * dp
        val th = max(28f * dp, track * height / total)
        val frac = ((-ty + 12f * dp) / (total - height)).coerceIn(0f, 1f)
        val top = 8f * dp + frac * (track - th)
        c.drawRoundRect(width - 5f * dp, top, width - 2f * dp, top + th, 2f * dp, 2f * dp, indPaint)
    }

    /** small picture of the note for the list */
    fun makeThumb(): Bitmap {
        val tw = 240
        val th = (tw * A4H / A4W).toInt()
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Cfg.PAPER[cfg.paperColor.coerceIn(0, Cfg.PAPER.size - 1)])
        var x0 = 0f; var y0 = 0f
        var sc = tw / A4W
        if (docMode == MODE_FREE && strokes.isNotEmpty()) {
            var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
            for (st in strokes) { val bd = st.bounds ?: boundsOf(st); l = min(l, bd.left); t = min(t, bd.top); r = max(r, bd.right); b = max(b, bd.bottom) }
            val w = max(r - l, 300f) ; val h = max(b - t, 300f)
            sc = min(tw / w, th / h)
            x0 = (l + r) / 2f - tw / sc / 2f; y0 = (t + b) / 2f - th / sc / 2f
        }
        c.scale(sc, sc); c.translate(-x0, -y0)
        renderDoc(c, x0, y0, x0 + tw / sc, y0 + th / sc, sc)
        return bmp
    }
}

