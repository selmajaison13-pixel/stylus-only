package com.sachin.stylusonly

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private const val NF = 4   // measured values per touch: size, minor axis, pressure, area

class DrawView(
    ctx: Context,
    private val cfg: Cfg,
    private val hud: (String, Boolean) -> Unit,
    private val toast: (String) -> Unit,
    private val onStatus: () -> Unit
) : View(ctx) {

    private class Stroke(val color: Int, val width: Float, val eraser: Boolean, val cal: Boolean) {
        val pts = ArrayList<PointF>()
        var path: Path? = null
        var pathN = -1
        var done = false
        var bounds: RectF? = null
    }

    private class Ptr(val id: Int, val tool: Int, val downT: Long) {
        var state = PEND
        var size = 0f
        var x = 0f
        var y = 0f
        var sx = 0f
        var sy = 0f
        val pts = ArrayList<PointF>()   // canvas coordinates, buffered until we decide
        var why: String? = null
        var seen = 0
        var n = 0
        val first = FloatArray(NF)
        val sum = FloatArray(NF)
        /** the first reading of a touch is often half formed, so it is skipped in the average */
        fun add(f: FloatArray) {
            if (seen == 0) { for (k in 0 until NF) first[k] = f[k] }
            else { for (k in 0 until NF) sum[k] += f[k]; n++ }
            seen++
        }
        fun mean(k: Int): Float = if (n > 0) sum[k] / n else first[k]
    }

    private companion object {
        const val PEND = 0      // just landed, deciding what it is
        const val CAND = 1      // looks like the stylus (temporary label)
        const val WRITER = 2    // the one contact that is writing
        const val FINGER = 3    // finger-sized: ignored for drawing, used for 2 finger pan
        const val PALM = 4      // palm-sized: ignored completely
        const val IGN = 5       // anything else: ignored
        const val MIN_SC = 0.4f
        const val MAX_SC = 5f
    }

    private val strokes = ArrayList<Stroke>()
    private val redoStack = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private val ptrs = LinkedHashMap<Int, Ptr>()
    private var writerId = -1
    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false
    private val decideRun = Runnable { scheduled = false; decide() }
    private val dp = resources.displayMetrics.density

    // canvas view (screen = canvas * sc + t)
    private var tx = 0f
    private var ty = 0f
    private var sc = 1f
    private var panning = false
    private var pLastCx = 0f
    private var pLastCy = 0f
    private var pLastD = 0f
    private var lastWriteEnd = 0L

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val deskPaint = Paint().apply { color = 0x22000000; style = Paint.Style.FILL }
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private val vis = RectF()

    var eraser = false
    var color = Color.BLACK
    var calibrating: String? = null

    private var mode = "none"   // none = not learned, size = match by contact size, pos = phone reports no size
    private var smin = 0f
    private var smax = 0f
    private var fmin = 0f
    private val sLo = FloatArray(NF)      // learned stylus fingerprint: lowest and highest value of each measurement
    private val sHi = FloatArray(NF)
    private val fnames = arrayOf("size", "minor", "pressure", "area")
    private val calSF = ArrayList<FloatArray>()
    private val calFF = ArrayList<FloatArray>()
    private val tmp = FloatArray(NF)
    private val prefs = cfg.prefs

    init {
        mode = prefs.getString("mode", "none") ?: "none"
        smin = prefs.getFloat("smin", 0f); smax = prefs.getFloat("smax", 0f); fmin = prefs.getFloat("fmin", 0f)
        val lo = prefs.getString("fpLo", "")?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: emptyList()
        val hi = prefs.getString("fpHi", "")?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: emptyList()
        if (lo.size == NF && hi.size == NF) {
            for (k in 0 until NF) { sLo[k] = lo[k]; sHi[k] = hi[k] }
        } else if (smax > 0f) {      // learned with the older version: only the size is known
            sLo[0] = smin; sHi[0] = smax
        }
        reloadCal()
        loadFromDisk()
    }

    // ---------- learned stylus size band ----------

    private fun hiLoose(): Float {
        var h = smax * 1.25f
        if (fmin > smax) h = min(h, (smax + fmin) / 2f)
        return h
    }

    /** biggest contact still accepted as the stylus; the strictness slider moves it */
    private fun hiEff(): Float {
        val loose = hiLoose()
        val strict = smax * 1.02f
        val t = (100 - cfg.strict) / 100f
        return max(smax, strict + (max(loose, strict) - strict) * t)
    }

    private fun loB(): Float = smin * 0.6f

    private fun palmThr(): Float =
        if (fmin > 0f) max(fmin * 1.7f, hiLoose() * 1.8f) else hiLoose() * 2.2f

    private fun fmt(v: Float): String = "%.2f".format(v)

    fun statusText(): String {
        if (mode == "pos") return "This phone reports no touch size. Only the position rule works."
        if (mode != "size") return "Not learned yet. Use Learn stylus."
        val sb = StringBuilder("Stylus fingerprint learned:")
        for (k in 0 until NF) if (sHi[k] > 0f) sb.append("\n  ").append(fnames[k]).append(" ").append(fmt(sLo[k])).append(" to ").append(fmt(sHi[k]))
        return sb.toString()
    }

    private fun parseCal(key: String, out: ArrayList<FloatArray>) {
        out.clear()
        val txt = prefs.getString(key, "") ?: ""
        for (row in txt.split(";")) {
            val v = row.split(",").mapNotNull { it.toFloatOrNull() }
            if (v.size == NF) out.add(v.toFloatArray())
        }
    }

    private fun saveCal() {
        prefs.edit()
            .putString("SF", calSF.joinToString(";") { it.joinToString(",") })
            .putString("FF", calFF.joinToString(";") { it.joinToString(",") })
            .apply()
    }

    private fun reloadCal() { parseCal("SF", calSF); parseCal("FF", calFF) }

    /** how far a touch's measurements may stray from the learned stylus fingerprint; f makes it tighter or looser */
    private fun whyNot(p: Ptr, f: Float): String? {
        val m = (0.1f + (100 - cfg.strict) / 100f * 0.9f) * f
        for (k in 0 until NF) {
            if (sHi[k] <= 0f) continue
            val v = p.mean(k)
            val tol = (sHi[k] - sLo[k]) * m + abs((sHi[k] + sLo[k]) / 2f) * 0.03f * f
            if (v < sLo[k] - tol || v > sHi[k] + tol)
                return fnames[k] + " " + fmt(v) + ", stylus is " + fmt(sLo[k]) + " to " + fmt(sHi[k])
        }
        return null
    }

    private fun desc(p: Ptr): String =
        "size " + fmt(p.mean(0)) + " minor " + fmt(p.mean(1)) + " pressure " + fmt(p.mean(2)) + " area " + fmt(p.mean(3))

    private fun feat(e: MotionEvent, i: Int, out: FloatArray) {
        val mj = e.getTouchMajor(i)
        out[0] = if (mj > 0f) mj else e.getSize(i) * 1000f
        out[1] = e.getTouchMinor(i)
        out[2] = e.getPressure(i) * 100f
        out[3] = e.getSize(i) * 1000f
    }

    private fun recordCal(p: Ptr) {
        val k = calibrating ?: return
        if (p.seen < 3) return
        if (k == "stylus" && p.state != WRITER) return
        val v = FloatArray(NF)
        for (j in 0 until NF) v[j] = p.mean(j)
        (if (k == "stylus") calSF else calFF).add(v)
    }

    private fun sizeOf(e: MotionEvent, i: Int): Float {
        val m = e.getTouchMajor(i)
        return if (m > 0f) m else e.getSize(i) * 1000f
    }

    private fun isStylusTool(t: Int) = t == MotionEvent.TOOL_TYPE_STYLUS || t == MotionEvent.TOOL_TYPE_ERASER

    private fun cx(x: Float) = (x - tx) / sc
    private fun cy(y: Float) = (y - ty) / sc

    // ---------- touch handling ----------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(decideRun); scheduled = false
                if (cur != null) finishStroke(null)
                ptrs.clear(); panning = false; writerId = -1
                requestUnbufferedDispatch(e)
                addPtr(e, 0)
            }
            MotionEvent.ACTION_POINTER_DOWN -> addPtr(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> onMove(e)
            MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_UP -> {
                up(e.getPointerId(e.actionIndex))
                ptrs.clear(); panning = false; writerId = -1
            }
            MotionEvent.ACTION_CANCEL -> cancelAll()   // keeps whatever was already written
        }
        return true
    }

    private fun addPts(list: ArrayList<PointF>, e: MotionEvent, i: Int) {
        for (h in 0 until e.historySize) list.add(PointF(cx(e.getHistoricalX(i, h)), cy(e.getHistoricalY(i, h))))
        list.add(PointF(cx(e.getX(i)), cy(e.getY(i))))
    }

    private fun addPtr(e: MotionEvent, i: Int) {
        val id = e.getPointerId(i)
        val p = Ptr(id, e.getToolType(i), SystemClock.uptimeMillis())
        p.size = sizeOf(e, i); p.x = e.getX(i); p.y = e.getY(i); p.sx = p.x; p.sy = p.y
        p.pts.add(PointF(cx(p.x), cy(p.y)))
        feat(e, i, tmp); p.add(tmp)
        ptrs[id] = p
        if (isStylusTool(p.tool) && ptrs.size == 1 && calibrating == null) {
            decide()   // phone says it is the stylus and nothing else touches: no delay
        } else if (!scheduled) {
            scheduled = true; handler.postDelayed(decideRun, 40)
        }
    }

    private fun onMove(e: MotionEvent) {
        for (i in 0 until e.pointerCount) {
            val p = ptrs[e.getPointerId(i)] ?: continue
            val sz = sizeOf(e, i)
            p.x = e.getX(i); p.y = e.getY(i)
            if (sz > p.size) p.size = sz
            feat(e, i, tmp); p.add(tmp)
            when (p.state) {
                PEND -> addPts(p.pts, e, i)
                WRITER -> {
                    val c = cur
                    if (c != null && p.id == writerId) {
                        addPts(c.pts, e, i)
                        // a contact that suddenly becomes huge was a palm landing, not the stylus
                        if (calibrating == null && mode == "size" && !isStylusTool(p.tool) && p.n >= 10 && whyNot(p, 1.4f) != null) {
                            p.state = IGN; cur = null; writerId = -1
                            hud("stopped: this contact is not the stylus", false)
                        } else if (calibrating == null && mode == "size" && !isStylusTool(p.tool) && sz > palmThr()) {
                            p.state = PALM; cur = null; writerId = -1
                            hud("big contact (palm), dropped", false)
                        }
                    }
                }
                FINGER -> if (mode == "size" && p.size > palmThr()) p.state = PALM
            }
        }
        updatePan()
        invalidate()
    }

    private fun up(id: Int) {
        val p = ptrs[id] ?: return
        if (p.state == PEND) { handler.removeCallbacks(decideRun); scheduled = false; decide() }
        if (calibrating != null) recordCal(p)
        if (p.state == WRITER && id == writerId) finishStroke(p)
        ptrs.remove(id)
        if (panning && countState(FINGER) < 2) panning = false
    }

    private fun cancelAll() {
        handler.removeCallbacks(decideRun); scheduled = false
        val w = ptrs[writerId]
        if (cur != null) finishStroke(w)
        ptrs.clear(); panning = false; writerId = -1; cur = null
        invalidate()
    }

    private fun countState(s: Int): Int {
        var n = 0
        for (p in ptrs.values) if (p.state == s) n++
        return n
    }

    private fun classify(p: Ptr, palmNear: Boolean): Int {
        if (isStylusTool(p.tool)) return CAND
        if (mode == "pos") return CAND
        if (mode != "size") return FINGER
        if (p.size > palmThr()) return PALM
        if (p.size < loB()) return IGN
        // the stylus has its own fingerprint (size, shape, pressure); a finger of the same size still differs in the others
        val w = whyNot(p, if (palmNear) 1.5f else 1f)
        p.why = w
        return if (w == null) CAND else FINGER
    }

    private fun decide() {
        val pend = ArrayList<Ptr>()
        for (p in ptrs.values) if (p.state == PEND) pend.add(p)
        if (pend.isEmpty()) return
        if (panning) { for (p in pend) p.state = FINGER; return }
        val cal = calibrating

        var palmNear = false
        if (mode == "size") for (p in ptrs.values) if (p.state == PALM || (p.state == PEND && p.size > palmThr())) palmNear = true

        val cands = ArrayList<Ptr>()
        for (p in pend) {
            val c = if (cal != null) CAND else classify(p, palmNear)
            if (c == CAND) cands.add(p) else {
                p.state = c
                hud(when {
                    mode == "none" -> "not learned yet. " + desc(p)
                    c == PALM -> "palm. " + desc(p)
                    else -> "not stylus: " + (p.why ?: desc(p))
                }, false)
            }
        }
        if (cands.isEmpty()) return

        val old = ptrs[writerId]
        if (writerId != -1 && old != null) {
            // already writing: a second contact never steals the pen, except a real stylus replacing a finger-type one
            val real = cands.firstOrNull { isStylusTool(it.tool) }
            if (real != null && !isStylusTool(old.tool)) {
                old.state = IGN; cur = null; writerId = -1
                for (p in cands) if (p !== real) p.state = IGN
                startWriter(real)
            } else {
                for (p in cands) p.state = IGN
                hud("second contact ignored", false)
            }
            return
        }
        val w = cands.firstOrNull { isStylusTool(it.tool) }
            ?: if (cands.all { it.size > 0f }) cands.minByOrNull { it.size }!! else cands.minByOrNull { it.pts[0].y }!!
        for (p in cands) if (p !== w) p.state = IGN
        startWriter(w)
    }

    private fun startWriter(w: Ptr) {
        w.state = WRITER; writerId = w.id; panning = false
        val er = eraser || w.tool == MotionEvent.TOOL_TYPE_ERASER
        val width = (if (er) cfg.eraser.toFloat() else cfg.penDp()) * dp
        val s = Stroke(color, width, er, calibrating != null)
        s.pts.addAll(w.pts)
        cur = s
        hud(desc(w), true)
        invalidate()
    }

    private fun finishStroke(p: Ptr?) {
        val c = cur
        cur = null; writerId = -1
        lastWriteEnd = SystemClock.uptimeMillis()
        if (c == null) return
        c.done = true
        if (!c.cal) {
            if (p != null && isFingerDot(c, p)) hud("tap from a finger ignored", false)
            else { strokes.add(c); redoStack.clear() }
        }
        invalidate()
    }

    /** a lone tap that is bigger than any stylus tap you taught is a fingertip, not a dot */
    private fun isFingerDot(c: Stroke, p: Ptr): Boolean {
        if (mode != "size" || isStylusTool(p.tool) || c.pts.isEmpty()) return false
        val a = c.pts[0]
        var far = 0f
        for (q in c.pts) far = max(far, hypot(q.x - a.x, q.y - a.y))
        if (far >= 2.5f * dp) return false
        if (!cfg.dots) return true                 // dots from taps switched off in Settings
        return whyNot(p, 0.5f) != null             // a dot must match the stylus fingerprint very closely
    }

    // ---------- two finger move / zoom ----------

    private fun updatePan() {
        if (!cfg.twoFinger || mode == "pos" || calibrating != null) { panning = false; return }
        // two touches that are not a real stylus, whatever the size rules decided about them
        val fs = ArrayList<Ptr>()
        var stylusTool = false
        for (p in ptrs.values) { if (isStylusTool(p.tool)) stylusTool = true else fs.add(p) }
        if (fs.size != 2 || stylusTool) { panning = false; return }
        val a = fs[0]; val b = fs[1]
        val mx = (a.x + b.x) / 2f; val my = (a.y + b.y) / 2f
        val d = hypot(a.x - b.x, a.y - b.y)
        if (!panning) {
            if (abs(a.downT - b.downT) > 300) return                      // not a deliberate two finger touch
            if (SystemClock.uptimeMillis() - lastWriteEnd < 600) return   // resting hand right after writing
            val ax = a.x - a.sx; val ay = a.y - a.sy
            val bx = b.x - b.sx; val by = b.y - b.sy
            val ma = hypot(ax, ay); val mb = hypot(bx, by)
            if (ma < 10 * dp || mb < 10 * dp) return                      // both must really move (a resting finger does not)
            val cos = (ax * bx + ay * by) / (ma * mb)
            val d0 = hypot(a.sx - b.sx, a.sy - b.sy)
            if (cos < 0.3f && abs(d - d0) < 18 * dp) return                // neither moving together nor pinching
            // it is a pan: drop anything these fingers started drawing
            val w = ptrs[writerId]
            if (w != null && (w === a || w === b)) { cur = null; writerId = -1 }
            a.state = FINGER; b.state = FINGER
            panning = true; pLastCx = mx; pLastCy = my; pLastD = d
            return
        }
        tx += mx - pLastCx; ty += my - pLastCy
        if (cfg.pinch && pLastD > 0f && d > 0f) {
            val ns = (sc * d / pLastD).coerceIn(MIN_SC, MAX_SC)
            val k = ns / sc
            tx = mx - (mx - tx) * k; ty = my - (my - ty) * k; sc = ns
        }
        pLastCx = mx; pLastCy = my; pLastD = d
    }

    fun resetView() { tx = 0f; ty = 0f; sc = 1f; invalidate() }

    // ---------- learning ----------

    fun startLearn(kind: String) {
        cancelAll()
        calibrating = kind
        if (kind == "stylus") calSF.clear() else calFF.clear()
        toast(if (kind == "stylus") "Draw 8 or more short separate lines with ONLY the stylus (change angle and pressure a little), then tap Done"
              else "Touch the screen 8 or more times with your fingers and palm (one, two, whole hand), then tap Done")
    }

    fun finishLearn() {
        cancelAll()
        val k = calibrating
        calibrating = null
        if (k != null) learn()
        invalidate()
    }

    fun abortLearn() { cancelAll(); calibrating = null; reloadCal(); invalidate() }

    fun resetLearning() {
        mode = "none"; smin = 0f; smax = 0f; fmin = 0f; calSF.clear(); calFF.clear()
        for (k in 0 until NF) { sLo[k] = 0f; sHi[k] = 0f }
        prefs.edit().remove("mode").remove("smin").remove("smax").remove("fmin").remove("SF").remove("FF").remove("fpLo").remove("fpHi").apply()
        onStatus()
    }

    private fun learn() {
        saveCal()
        if (calSF.size < 4) { toast("Draw at least 4 separate lines with the stylus first (8 is better)"); return }
        // drop a stray palm that got into the stylus samples
        val sizes = calSF.map { it[0] }.sorted()
        val med = sizes[sizes.size / 2]
        val rows = calSF.filter { it[0] <= med * 1.6f }
        if (med <= 0f) {
            mode = "pos"; prefs.edit().putString("mode", mode).apply(); onStatus()
            toast("This phone reports no touch size, so it cannot tell a finger from the stylus. Only the position rule is active.")
            return
        }
        for (k in 0 until NF) {
            var v = rows.map { it[k] }.sorted()
            if (v.size >= 12) v = v.subList(1, v.size - 1)
            sLo[k] = v.first(); sHi[k] = v.last()
        }
        smin = sLo[0]; smax = sHi[0]
        val f = calFF.map { it[0] }.sorted()
        fmin = if (f.size >= 3) f[f.size / 5] else 0f
        var best = -1
        var bestOv = 2f
        if (calFF.size >= 3) for (k in 0 until NF) {
            if (sHi[k] <= 0f) continue
            var inside = 0
            for (r in calFF) if (r[k] >= sLo[k] * 0.9f && r[k] <= sHi[k] * 1.1f) inside++
            val ov = inside / calFF.size.toFloat()
            if (ov < bestOv) { bestOv = ov; best = k }
        }
        var msg = "Stylus fingerprint learned from ${rows.size} lines."
        if (calFF.size < 3) msg += " Now do Learn fingers too: it lets the app check how well fingers are told apart."
        else if (best >= 0 && bestOv > 0.5f) msg += " Warning: your fingers look like the stylus in every measurement this phone gives. Turn off Allow dots and keep strictness high."
        else if (best >= 0) msg += " Best at telling fingers apart: ${fnames[best]}."
        mode = "size"
        prefs.edit().putString("mode", mode).putFloat("smin", smin).putFloat("smax", smax).putFloat("fmin", fmin)
            .putString("fpLo", sLo.joinToString(",")).putString("fpHi", sHi.joinToString(",")).apply()
        onStatus(); toast(msg)
    }

    // ---------- undo, clear, save ----------

    fun undo() { if (strokes.isNotEmpty()) { redoStack.add(strokes.removeAt(strokes.size - 1)); invalidate() } }
    fun redo() { if (redoStack.isNotEmpty()) { strokes.add(redoStack.removeAt(redoStack.size - 1)); invalidate() } }
    fun clearAll() { strokes.clear(); redoStack.clear(); invalidate() }

    fun saveToDisk() {
        try {
            val f = File(context.filesDir, "page.bin")
            DataOutputStream(BufferedOutputStream(FileOutputStream(f))).use { o ->
                o.writeInt(1); o.writeFloat(tx); o.writeFloat(ty); o.writeFloat(sc)
                o.writeInt(strokes.size)
                for (s in strokes) {
                    o.writeInt(s.color); o.writeFloat(s.width); o.writeBoolean(s.eraser); o.writeInt(s.pts.size)
                    for (p in s.pts) { o.writeFloat(p.x); o.writeFloat(p.y) }
                }
            }
        } catch (ex: Exception) { }
    }

    private fun loadFromDisk() {
        try {
            val f = File(context.filesDir, "page.bin")
            if (!f.exists()) return
            DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
                if (i.readInt() != 1) return
                tx = i.readFloat(); ty = i.readFloat(); sc = i.readFloat().coerceIn(MIN_SC, MAX_SC)
                val n = i.readInt()
                for (k in 0 until n) {
                    val col = i.readInt(); val w = i.readFloat(); val er = i.readBoolean(); val m = i.readInt()
                    val s = Stroke(col, w, er, false)
                    for (j in 0 until m) s.pts.add(PointF(i.readFloat(), i.readFloat()))
                    s.done = true
                    strokes.add(s)
                }
            }
        } catch (ex: Exception) { }
    }

    // ---------- drawing ----------

    private fun buildPath(p: List<PointF>): Path {
        val path = Path()
        if (p.isEmpty()) return path
        path.moveTo(p[0].x, p[0].y)
        if (p.size == 1) { path.lineTo(p[0].x + 0.1f, p[0].y); return path }
        for (i in 1 until p.size - 1) path.quadTo(p[i].x, p[i].y, (p[i].x + p[i + 1].x) / 2, (p[i].y + p[i + 1].y) / 2)
        path.lineTo(p.last().x, p.last().y)
        return path
    }

    private fun boundsOf(s: Stroke): RectF {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (p in s.pts) { l = min(l, p.x); t = min(t, p.y); r = max(r, p.x); b = max(b, p.y) }
        val pad = s.width
        return RectF(l - pad, t - pad, r + pad, b + pad)
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        var path = s.path
        if (path == null || s.pathN != s.pts.size) {
            path = buildPath(s.pts); s.path = path; s.pathN = s.pts.size
        }
        if (s.eraser) { paint.xfermode = clearMode; paint.color = Color.BLACK }
        else { paint.xfermode = null; paint.color = s.color }
        paint.strokeWidth = s.width
        c.drawPath(path, paint)
        paint.xfermode = null
    }

    private fun drawPaper(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        val sp = max(8f, cfg.spacing * dp)
        val top = cfg.topMargin * dp
        val hair = max(1f, 0.6f * dp) / sc
        gp.color = Cfg.LINE[cfg.lineColor.coerceIn(0, Cfg.LINE.size - 1)]
        gp.strokeWidth = hair
        gp.strokeCap = Paint.Cap.BUTT
        val x0 = max(l, 0f)
        val style = cfg.paper
        if (r > x0) {
            if (style == 1 || style == 2) {
                var k = ceil((max(t, top) - top) / sp).toInt()
                var y = top + k * sp
                var n = 0
                while (y <= b && n < 800) { c.drawLine(x0, y, r, y, gp); k++; y = top + k * sp; n++ }
            }
            if (style == 2) {
                val yv = max(t, top)
                var kx = ceil(x0 / sp).toInt()
                var x = kx * sp
                var n = 0
                while (x <= r && n < 800) { c.drawLine(x, yv, x, b, gp); kx++; x = kx * sp; n++ }
            }
            if (style == 3) {
                val k0 = ceil((max(t, top) - top) / sp).toInt()
                val kx0 = ceil(x0 / sp).toInt()
                val cols = floor(r / sp).toInt() - kx0 + 1
                val rows = floor((b - top) / sp).toInt() - k0 + 1
                if (cols > 0 && rows > 0 && cols * rows <= 20000) {
                    val arr = FloatArray(cols * rows * 2)
                    var i = 0
                    for (jy in 0 until rows) for (jx in 0 until cols) {
                        arr[i++] = (kx0 + jx) * sp; arr[i++] = top + (k0 + jy) * sp
                    }
                    gp.strokeCap = Paint.Cap.ROUND
                    gp.strokeWidth = 2.6f * dp / sc
                    c.drawPoints(arr, 0, i, gp)
                    gp.strokeCap = Paint.Cap.BUTT
                }
            }
        }
        if (cfg.leftMargin) {
            val mx = cfg.leftMarginPos * dp
            val y0 = max(t, 0f)
            if (mx >= l && mx <= r && b > y0) {
                gp.color = Cfg.MARGIN; gp.strokeWidth = hair * 1.4f
                c.drawLine(mx, y0, mx, b, gp)
            }
        }
        // the area outside the page (left of and above it) is a slightly darker desk
        if (l < 0f) c.drawRect(l, t, 0f, b, deskPaint)
        if (t < 0f) c.drawRect(max(l, 0f), t, r, 0f, deskPaint)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Cfg.PAPER[cfg.paperColor.coerceIn(0, Cfg.PAPER.size - 1)])
        val l = -tx / sc; val t = -ty / sc
        val r = (width - tx) / sc; val b = (height - ty) / sc
        c.save()
        c.translate(tx, ty); c.scale(sc, sc)
        drawPaper(c, l, t, r, b)
        vis.set(l, t, r, b)
        // strokes live in their own layer so the eraser removes ink but never the notebook lines
        val layer = c.saveLayer(l, t, r, b, null)
        for (s in strokes) {
            var bd = s.bounds
            if (bd == null) { bd = boundsOf(s); s.bounds = bd }
            if (RectF.intersects(vis, bd)) drawStroke(c, s)
        }
        cur?.let { drawStroke(c, it) }
        c.restoreToCount(layer)
        c.restore()
    }
}
