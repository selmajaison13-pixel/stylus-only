package com.sachin.stylusonly

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var draw: DrawView
    private lateinit var toolbar: HorizontalScrollView
    private lateinit var info: TextView
    private lateinit var handle: TextView
    private lateinit var calBar: LinearLayout
    private lateinit var calText: TextView
    private lateinit var penChip: TextView
    private lateinit var eraserChip: TextView
    private lateinit var fullChip: TextView
    private val swatches = ArrayList<View>()
    private val inks = intArrayOf(0xFF111111.toInt(), 0xFF1F4FD8.toInt(), 0xFFD64545.toInt(), 0xFF1F9D55.toInt(), 0xFFF28C28.toInt())
    private var ci = 0
    private var fullscreen = false
    private var dpf = 1f
    private val accent = 0xFF3D6DF2.toInt()
    private val barColor = 0xEE1E2433.toInt()

    private fun dp(v: Int): Int = (v * dpf).toInt()

    private fun rr(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    /** ignore touches from a big contact (a palm) on the buttons */
    private fun guard(v: View) {
        v.setOnTouchListener { _, ev -> ev.getTouchMajor(0) > dp(110) }
    }

    private fun chip(text: String, f: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(14), dp(9), dp(14), dp(9))
        setOnClickListener { f() }
        guard(this)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dpf = resources.displayMetrics.density
        cfg = Cfg(this)

        info = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); text = "Ready"
            setPadding(dp(10), dp(5), dp(10), dp(5)); background = rr(0xAA1E2433.toInt(), 14)
        }
        draw = DrawView(this, cfg,
            { t, ok -> info.text = (if (ok) "Stylus: " else "Ignored: ") + t },
            { m -> Toast.makeText(this, m, Toast.LENGTH_LONG).show() },
            { })

        val root = FrameLayout(this)
        root.addView(draw, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(10), 0, 0, dp(10)) })

        // ----- top tool bar -----
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        penChip = chip("Pen") { draw.eraser = false; refreshToolbar() }
        eraserChip = chip("Eraser") { draw.eraser = true; refreshToolbar() }
        bar.addView(penChip); bar.addView(eraserChip)
        for (i in inks.indices) {
            val sw = View(this)
            sw.setOnClickListener { ci = i; draw.color = inks[i]; draw.eraser = false; refreshToolbar() }
            guard(sw)
            swatches.add(sw)
            bar.addView(sw, LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
        bar.addView(chip("Undo") { draw.undo() })
        bar.addView(chip("Redo") { draw.redo() })
        bar.addView(chip("Fit") { draw.resetView() })
        fullChip = chip("Full screen") { setFullscreen(!fullscreen) }
        bar.addView(fullChip)
        bar.addView(chip("Settings") { showSettings() })
        toolbar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = rr(barColor, 26); elevation = dp(6).toFloat()
            addView(bar)
        }
        root.addView(toolbar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { setMargins(dp(8), dp(8), dp(8), 0) })

        // ----- small handle that shows the tool bar while in full screen -----
        handle = TextView(this).apply {
            text = "\u22EE"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rr(0x991E2433.toInt(), 22); visibility = View.GONE
            setOnClickListener { toolbar.visibility = if (toolbar.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        guard(handle)
        root.addView(handle, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START).apply { setMargins(dp(8), dp(8), 0, 0) })

        // ----- learning bar -----
        calText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), 0, dp(12), 0) }
        calBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(10), dp(8)); background = rr(barColor, 24); visibility = View.GONE
            addView(calText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(chip("Done") { draw.finishLearn(); calBar.visibility = View.GONE }.apply { background = rr(accent, 18) })
            addView(chip("Cancel") { draw.abortLearn(); calBar.visibility = View.GONE })
        }
        root.addView(calBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM).apply { setMargins(dp(10), 0, dp(10), dp(10)) })

        setContentView(root)
        applyCfg()
        refreshToolbar()
    }

    private fun applyCfg() {
        draw.keepScreenOn = cfg.keepOn
        info.visibility = if (cfg.showInfo && !fullscreen) View.VISIBLE else View.GONE
        draw.invalidate()
    }

    private fun refreshToolbar() {
        penChip.background = if (!draw.eraser) rr(accent, 18) else null
        eraserChip.background = if (draw.eraser) rr(accent, 18) else null
        for ((i, v) in swatches.withIndex()) {
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(inks[i])
                setStroke(dp(2), if (i == ci && !draw.eraser) Color.WHITE else 0x44FFFFFF)
            }
        }
    }

    // ---------- full screen ----------

    @Suppress("DEPRECATION")
    private fun applyBars(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            window.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController
            if (c != null) {
                if (on) {
                    c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    c.hide(WindowInsets.Type.systemBars())
                } else c.show(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = if (on)
                (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
            else View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        applyBars(on)
        toolbar.visibility = if (on) View.GONE else View.VISIBLE
        handle.visibility = if (on) View.VISIBLE else View.GONE
        fullChip.text = if (on) "Exit full screen" else "Full screen"
        applyCfg()
        if (on) Toast.makeText(this, "Full screen. Tap the dots at top left for tools. Back button exits.", Toast.LENGTH_SHORT).show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && fullscreen) applyBars(true)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (fullscreen) setFullscreen(false) else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        draw.saveToDisk()
        cfg.save()
    }

    // ---------- settings ----------

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title; textSize = 17f; setTextColor(accent); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(2))
        })
    }

    private fun segmented(parent: LinearLayout, label: String, options: List<String>, current: Int, onPick: (Int) -> Unit) {
        parent.addView(TextView(this).apply { text = label; textSize = 14f; setPadding(0, dp(12), 0, dp(4)) })
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paintSel(sel: Int) {
            for ((i, v) in views.withIndex()) {
                v.background = rr(if (i == sel) accent else 0xFFE6E8EE.toInt(), 10)
                v.setTextColor(if (i == sel) Color.WHITE else 0xFF333333.toInt())
            }
        }
        for ((i, o) in options.withIndex()) {
            val v = TextView(this).apply {
                text = o; gravity = Gravity.CENTER; textSize = 13f
                setPadding(dp(4), dp(10), dp(4), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            }
            v.setOnClickListener { paintSel(i); onPick(i); draw.invalidate() }
            views.add(v); row.addView(v)
        }
        paintSel(current)
        parent.addView(row)
    }

    private fun slider(parent: LinearLayout, label: String, vMin: Int, vMax: Int, cur: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
        val tv = TextView(this).apply { textSize = 14f; setPadding(0, dp(12), 0, 0) }
        tv.text = label + ": " + fmt(cur)
        val sb = SeekBar(this)
        sb.max = vMax - vMin
        sb.progress = cur - vMin
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + vMin
                tv.text = label + ": " + fmt(v)
                if (fromUser) { onChange(v); draw.invalidate() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv); parent.addView(sb)
    }

    private fun toggle(parent: LinearLayout, label: String, cur: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = label; sw.textSize = 14f; sw.isChecked = cur
        sw.setPadding(0, dp(10), 0, dp(10))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw)
    }

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(12)) }
        val sv = ScrollView(this).apply { addView(col) }
        var dlg: AlertDialog? = null

        section(col, "Paper")
        segmented(col, "Page style", listOf("Blank", "Lines", "Grid", "Dots"), cfg.paper) { cfg.paper = it; cfg.save() }
        segmented(col, "Paper colour", Cfg.PAPER_NAMES, cfg.paperColor) { cfg.paperColor = it; cfg.save() }
        segmented(col, "Line colour", Cfg.LINE_NAMES, cfg.lineColor) { cfg.lineColor = it; cfg.save() }
        slider(col, "Line spacing", 16, 80, cfg.spacing, { "$it dp" }) { cfg.spacing = it; cfg.save() }

        section(col, "Margins")
        toggle(col, "Left margin line (red)", cfg.leftMargin) { cfg.leftMargin = it; cfg.save(); draw.invalidate() }
        slider(col, "Left margin position", 0, 200, cfg.leftMarginPos, { "$it dp" }) { cfg.leftMarginPos = it; cfg.save() }
        slider(col, "Top margin (space before first line)", 0, 240, cfg.topMargin, { "$it dp" }) { cfg.topMargin = it; cfg.save() }

        section(col, "Pen")
        slider(col, "Pen thickness", 1, 24, cfg.pen, { "${it / 2f} dp" }) { cfg.pen = it; cfg.save() }
        slider(col, "Eraser size", 6, 80, cfg.eraser, { "$it dp" }) { cfg.eraser = it; cfg.save() }

        section(col, "Touch")
        toggle(col, "Move canvas with 2 fingers", cfg.twoFinger) { cfg.twoFinger = it; cfg.save() }
        toggle(col, "Pinch with 2 fingers to zoom", cfg.pinch) { cfg.pinch = it; cfg.save() }
        slider(col, "Finger and palm rejection strictness", 0, 100, cfg.strict, { "$it%" }) { cfg.strict = it; cfg.save() }
        col.addView(TextView(this).apply {
            text = "Higher = only touches very close to your stylus size can draw. If the stylus gets ignored, lower it. If fingers still make dots, raise it."
            textSize = 12f; setTextColor(0xFF666666.toInt())
        })
        toggle(col, "Show touch info (bottom left)", cfg.showInfo) { cfg.showInfo = it; cfg.save(); applyCfg() }
        toggle(col, "Keep screen on while writing", cfg.keepOn) { cfg.keepOn = it; cfg.save(); applyCfg() }

        section(col, "Learn stylus and fingers")
        val st = TextView(this).apply { text = draw.statusText(); textSize = 13f; setPadding(0, dp(4), 0, dp(8)) }
        col.addView(st)
        fun learnBtn(label: String, kind: String, hint: String): Button = Button(this).apply {
            text = label; isAllCaps = false
            setOnClickListener {
                dlg?.dismiss()
                draw.startLearn(kind)
                calText.text = hint
                calBar.visibility = View.VISIBLE
            }
        }
        col.addView(learnBtn("1. Learn stylus", "stylus", "Write short lines with ONLY the stylus (5 or more), then Done"))
        col.addView(learnBtn("2. Learn fingers and palm", "finger", "Touch with fingers and palm 8 or more times, then Done"))
        col.addView(Button(this).apply {
            text = "Forget what was learned"; isAllCaps = false
            setOnClickListener { draw.resetLearning(); st.text = draw.statusText() }
        })

        section(col, "Page")
        col.addView(Button(this).apply {
            text = "Clear page"; isAllCaps = false
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("Clear the whole page?")
                    .setPositiveButton("Clear") { _, _ -> draw.clearAll() }
                    .setNegativeButton("Cancel", null).show()
            }
        })

        dlg = AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done", null).create()
        dlg.setOnDismissListener { cfg.save(); applyCfg() }
        dlg.show()
    }
}
