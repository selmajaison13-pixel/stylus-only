package com.sachin.stylusonly

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var store: NoteStore
    private lateinit var draw: DrawView
    private lateinit var editor: FrameLayout
    private lateinit var toolbar: HorizontalScrollView
    private lateinit var info: TextView
    private lateinit var handle: TextView
    private lateinit var calBar: LinearLayout
    private lateinit var calText: TextView
    private lateinit var penChip: TextView
    private lateinit var eraserChip: TextView
    private lateinit var handChip: TextView
    private lateinit var titleChip: TextView
    private lateinit var savedChip: TextView
    private lateinit var lockChip: TextView
    private lateinit var navChip: TextView
    private lateinit var pageChip: TextView
    private lateinit var navPad: LinearLayout
    private val swatches = ArrayList<View>()
    private val inks = intArrayOf(0xFF111111.toInt(), 0xFF1F4FD8.toInt(), 0xFFD64545.toInt(), 0xFF1F9D55.toInt(), 0xFFF28C28.toInt())
    private var ci = 0
    private var dpf = 1f
    private val accent = 0xFF3D6DF2.toInt()
    private val barColor = 0xEE1E2433.toInt()

    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var inEditor = false
    private var dirty = false
    private var toolsOpen = true
    private var writingNow = false
    private var navOn = false
    private var pendingIds: List<String>? = null
    private var navDx = 0f
    private var navDy = 0f

    private val REQ_BACKUP = 11
    private val REQ_EXPORT = 12
    private val REQ_RESTORE = 13

    private val autoSaveRun = Runnable { saveNow(false, false) }
    private val showToolsRun = Runnable { refreshChrome() }
    private val navRun = object : Runnable {
        override fun run() {
            if (navDx != 0f || navDy != 0f) { draw.scrollBy(navDx * dpf, navDy * dpf); ui.postDelayed(this, 16) }
        }
    }

    private fun dp(v: Int): Int = (v * dpf).toInt()
    private fun say(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun rr(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    /** ignore touches from a big contact (a palm) on the buttons */
    private fun guard(v: View) {
        v.setOnTouchListener { _, ev -> ev.getTouchMajor(0) > dp(110) }
    }

    private fun chip(text: String, f: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(9), dp(12), dp(9))
        setOnClickListener { f() }
        guard(this)
    }

    private fun stamp(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    // =====================================================================
    // start
    // =====================================================================

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dpf = resources.displayMetrics.density
        cfg = Cfg(this)
        store = NoteStore(filesDir)
        store.migrateOld(dpf)

        info = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); text = "Ready"
            setPadding(dp(10), dp(5), dp(10), dp(5)); background = rr(0xAA1E2433.toInt(), 14)
        }
        draw = DrawView(this, cfg,
            { t, ok -> info.text = (if (ok) "Stylus: " else "Ignored: ") + t },
            { m -> say(m) },
            { },
            { changed() },
            { w -> onWriting(w) })
        draw.learnProgress = { t -> calText.text = t }
        buildEditor()
        showLibrary()
    }

    // =====================================================================
    // editor screen
    // =====================================================================

    private fun buildEditor() {
        editor = FrameLayout(this)
        editor.addView(draw, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        editor.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(10), 0, 0, dp(10)) })

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        bar.addView(chip("\u2190") { closeNote() })
        titleChip = chip("Note") { renameDialog(draw.note.title) { t -> draw.note.title = t; titleChip.text = t; changed() } }.apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = dp(120); setTypeface(null, Typeface.BOLD)
        }
        bar.addView(titleChip)
        savedChip = TextView(this).apply { textSize = 11f; setTextColor(0xFFB8C0D4.toInt()); text = "Saved"; setPadding(dp(2), 0, dp(8), 0) }
        bar.addView(savedChip)
        penChip = chip("Pen") { draw.eraser = false; draw.hand = false; refreshToolbar() }
        eraserChip = chip("Eraser") { draw.eraser = true; draw.hand = false; refreshToolbar() }
        handChip = chip("Hand") { draw.hand = !draw.hand; refreshToolbar() }
        bar.addView(penChip); bar.addView(eraserChip); bar.addView(handChip)
        for (i in inks.indices) {
            val sw = View(this)
            sw.setOnClickListener { ci = i; draw.color = inks[i]; draw.eraser = false; draw.hand = false; refreshToolbar() }
            guard(sw)
            swatches.add(sw)
            bar.addView(sw, LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
        bar.addView(chip("Undo") { draw.undo() })
        bar.addView(chip("Redo") { draw.redo() })
        bar.addView(chip("\u2212") { draw.zoomBy(0.8f) })
        bar.addView(chip("+") { draw.zoomBy(1.25f) })
        bar.addView(chip("Fit") { draw.fit() })
        navChip = chip("Move") { navOn = !navOn; refreshChrome(); refreshToolbar() }
        bar.addView(navChip)
        pageChip = chip("+ Page") { draw.addPage(); say("Page " + draw.pageCount() + " added") }
        bar.addView(pageChip)
        bar.addView(chip("Save") { saveNow(true, false); say("Saved") })
        lockChip = chip("Lock") { togglePin() }
        bar.addView(lockChip)
        bar.addView(chip("Hide tools") { toolsOpen = false; refreshChrome() })
        bar.addView(chip("Settings") { showSettings() })
        toolbar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = rr(barColor, 26); elevation = dp(6).toFloat()
            addView(bar)
        }
        editor.addView(toolbar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { setMargins(dp(8), dp(8), dp(8), 0) })

        handle = TextView(this).apply {
            text = "\u22EE"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rr(0x991E2433.toInt(), 22); visibility = View.GONE
            setOnClickListener { toolsOpen = true; refreshChrome() }
        }
        guard(handle)
        editor.addView(handle, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START).apply { setMargins(dp(8), dp(8), 0, 0) })

        // arrow pad: moves the page without touching it with fingers
        navPad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val r1 = LinearLayout(this); val r2 = LinearLayout(this)
        r1.addView(pageBtn("\u21DE", -1)); r1.addView(navBtn("\u25B2", 0f, -12f)); r1.addView(pageBtn("\u21DF", 1))
        r2.addView(navBtn("\u25C0", -12f, 0f)); r2.addView(navBtn("\u25BC", 0f, 12f)); r2.addView(navBtn("\u25B6", 12f, 0f))
        navPad.addView(r1); navPad.addView(r2)
        editor.addView(navPad, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(10), dp(14)) })

        calText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), 0, dp(12), 0) }
        calBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(10), dp(8)); background = rr(barColor, 24); visibility = View.GONE
            addView(calText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(chip("Done") { draw.finishLearn(); calBar.visibility = View.GONE }.apply { background = rr(accent, 18) })
            addView(chip("Cancel") { draw.abortLearn(); calBar.visibility = View.GONE })
        }
        editor.addView(calBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM).apply { setMargins(dp(10), 0, dp(10), dp(10)) })
    }

    private fun padBtn(label: String): TextView = TextView(this).apply {
        text = label; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = rr(0xBB1E2433.toInt(), 20)
        layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
    }

    /** press and hold: the page keeps moving */
    private fun navBtn(label: String, dx: Float, dy: Float): TextView = padBtn(label).apply {
        setOnTouchListener { _, ev ->
            if (ev.getTouchMajor(0) > dp(110)) return@setOnTouchListener true
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { navDx = dx; navDy = dy; ui.removeCallbacks(navRun); ui.post(navRun) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { navDx = 0f; navDy = 0f }
            }
            true
        }
    }

    private fun pageBtn(label: String, dir: Int): TextView = padBtn(label).apply {
        setOnClickListener { draw.pageStep(dir) }
        guard(this)
    }

    private fun applyCfg() {
        draw.keepScreenOn = cfg.keepOn
        draw.blockGestures = cfg.blockGestures
        refreshChrome()
        draw.invalidate()
    }

    private fun refreshToolbar() {
        penChip.background = if (!draw.eraser && !draw.hand) rr(accent, 18) else null
        eraserChip.background = if (draw.eraser && !draw.hand) rr(accent, 18) else null
        handChip.background = if (draw.hand) rr(accent, 18) else null
        navChip.background = if (navOn) rr(accent, 18) else null
        for ((i, v) in swatches.withIndex()) {
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(inks[i])
                setStroke(dp(2), if (i == ci && !draw.eraser && !draw.hand) Color.WHITE else 0x44FFFFFF)
            }
        }
        pageChip.visibility = if (draw.isA4()) View.VISIBLE else View.GONE
        val p = isPinned()
        lockChip.text = if (p) "Unlock" else "Lock"
        lockChip.background = if (p) rr(0xFFC62828.toInt(), 18) else null
    }

    /** tools show or hide: hidden while the pen writes (so nothing is in the way) and back a moment after */
    private fun refreshChrome() {
        if (!inEditor) return
        val hide = writingNow && cfg.hideWhileWriting
        val show = toolsOpen && !hide
        toolbar.visibility = if (show) View.VISIBLE else View.GONE
        navPad.visibility = if (show && navOn) View.VISIBLE else View.GONE
        handle.visibility = if (!toolsOpen && !hide) View.VISIBLE else View.GONE
        info.visibility = if (cfg.showInfo && toolsOpen) View.VISIBLE else View.GONE
    }

    private fun onWriting(w: Boolean) {
        writingNow = w
        ui.removeCallbacks(showToolsRun)
        if (w) refreshChrome() else ui.postDelayed(showToolsRun, 900)
    }

    // =====================================================================
    // saving
    // =====================================================================

    private fun changed() {
        dirty = true
        ui.removeCallbacks(autoSaveRun)
        ui.postDelayed(autoSaveRun, 1500)
        if (inEditor) savedChip.text = "Saving\u2026"
    }

    /** writes the open note to its own file; sync = wait until it is on disk */
    private fun saveNow(sync: Boolean, thumb: Boolean) {
        if (!inEditor) return
        ui.removeCallbacks(autoSaveRun)
        val id = draw.note.id
        val need = dirty || (thumb && !store.thumbFile(id).exists())
        if (!need) return
        val snap = draw.snapshot()
        val bmp = if (thumb) try { draw.makeThumb() } catch (ex: Exception) { null } else null
        dirty = false
        val job = Runnable {
            store.save(snap)
            if (bmp != null) store.saveThumb(snap.id, bmp)
            ui.post { savedChip.text = "Saved " + stamp() }
        }
        if (sync) { try { exec.submit(job).get() } catch (ex: Exception) { } } else exec.execute(job)
    }

    override fun onPause() {
        super.onPause()
        saveNow(true, false)
        cfg.save()
    }

    override fun onResume() {
        super.onResume()
        if (inEditor) { applyBars(cfg.immersive); refreshToolbar() }
    }

    // =====================================================================
    // system bars and locking
    // =====================================================================

    @Suppress("DEPRECATION")
    private fun applyBars(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            window.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController
            if (c != null) {
                if (on) {
                    c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    c.hide(WindowInsets.Type.systemBars())
                } else c.show(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = if (on)
                (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            else View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && inEditor) { applyBars(cfg.immersive); refreshToolbar() }
    }

    private fun isPinned(): Boolean = try {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    } catch (ex: Exception) { false }

    /** screen pinning: Android itself stops Home, Recents and swipes from leaving the app */
    private fun togglePin() {
        if (isPinned()) {
            try { stopLockTask() } catch (ex: Exception) { }
            ui.postDelayed({ refreshToolbar() }, 500)
            return
        }
        AlertDialog.Builder(this).setTitle("Lock the app on screen?")
            .setMessage("Android will pin this app. Home, Recents and edge swipes then cannot minimise it while you write.\n\n" +
                "To unlock: tap Unlock here, or hold Back and Overview together (on gesture navigation: swipe up and hold).\n\n" +
                "If nothing happens, switch on Phone Settings > Security > Screen pinning (the name differs a little on each phone).")
            .setPositiveButton("Lock") { _, _ ->
                try { startLockTask() } catch (ex: Exception) { say("This phone refused screen pinning. Switch it on in Phone Settings.") }
                ui.postDelayed({ refreshToolbar() }, 700)
            }
            .setNegativeButton("Cancel", null).show()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (inEditor) {
            if (draw.isWritingNow()) return      // a palm touching the edge never closes the note while you write
            closeNote()
        } else super.onBackPressed()
    }

    // =====================================================================
    // notes list
    // =====================================================================

    private fun libChip(text: String, filled: Boolean, f: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 14f; gravity = Gravity.CENTER
        setTextColor(if (filled) Color.WHITE else accent)
        background = rr(if (filled) accent else 0xFFE3E9FD.toInt(), 12)
        setPadding(dp(14), dp(11), dp(14), dp(11))
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    private fun showLibrary() {
        inEditor = false
        val notes = store.list()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF3F4F8.toInt()) }
        root.addView(TextView(this).apply {
            text = "Stylus Notes"; textSize = 26f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF1E2433.toInt())
            setPadding(dp(18), dp(20), dp(18), dp(2))
        })
        root.addView(TextView(this).apply {
            text = "${notes.size} note" + (if (notes.size == 1) "" else "s") + " \u00B7 every note saves itself automatically"
            textSize = 13f; setTextColor(0xFF666666.toInt()); setPadding(dp(18), 0, dp(18), dp(10))
        })
        val row = LinearLayout(this).apply { setPadding(dp(12), 0, dp(12), dp(8)) }
        row.addView(libChip("+ New note", true) { newNoteDialog() })
        row.addView(libChip("Backup", false) { startBackup(null) })
        row.addView(libChip("Restore", false) { startRestore() })
        root.addView(row)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(24)) }
        if (notes.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No notes yet.\nTap  + New note  to start. A4 sheet is the default, or choose Unlimited space.\n\nHave a backup file? Tap Restore."
                textSize = 15f; setTextColor(0xFF555555.toInt()); setPadding(dp(8), dp(30), dp(8), 0)
            })
        }
        val df = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
        for (n in notes) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rr(Color.WHITE, 14); elevation = dp(2).toFloat()
                setPadding(dp(10), dp(10), dp(6), dp(10))
                setOnClickListener { openNote(n.id) }
                setOnLongClickListener { noteMenu(n); true }
            }
            val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rr(0xFFE6E8EE.toInt(), 8) }
            val tf = store.thumbFile(n.id)
            if (tf.exists()) try { img.setImageBitmap(BitmapFactory.decodeFile(tf.path)) } catch (ex: Exception) { }
            card.addView(img, LinearLayout.LayoutParams(dp(62), dp(88)))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(6), 0) }
            col.addView(TextView(this).apply {
                text = n.title; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF1E2433.toInt())
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
            val kind = if (n.mode == MODE_A4) "A4 \u00B7 ${n.pages} page" + (if (n.pages == 1) "" else "s") else "Unlimited space"
            col.addView(TextView(this).apply { text = kind + " \u00B7 ${n.strokeCount} strokes"; textSize = 13f; setTextColor(0xFF666666.toInt()); setPadding(0, dp(3), 0, 0) })
            col.addView(TextView(this).apply { text = df.format(Date(n.modified)); textSize = 12f; setTextColor(0xFF888888.toInt()); setPadding(0, dp(2), 0, 0) })
            card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(TextView(this).apply {
                text = "\u22EE"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(0xFF444444.toInt())
                setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { noteMenu(n) }
            })
            list.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        applyBars(false)
    }

    private fun newNoteDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0) }
        val et = EditText(this).apply {
            setText("Note " + SimpleDateFormat("d MMM", Locale.getDefault()).format(Date())); setSelectAllOnFocus(true); setSingleLine()
        }
        col.addView(et)
        val rg = RadioGroup(this)
        val rA = RadioButton(this).apply { text = "A4 sheet (default)"; id = 101 }
        val rF = RadioButton(this).apply { text = "Unlimited space"; id = 102 }
        rg.addView(rA); rg.addView(rF); rg.check(101)
        col.addView(rg)
        AlertDialog.Builder(this).setTitle("New note").setView(col)
            .setPositiveButton("Create") { _, _ ->
                val t = et.text.toString().trim().ifEmpty { "Untitled" }
                val now = System.currentTimeMillis()
                val n = Note(store.newId(), t, now, now, if (rF.isChecked) MODE_FREE else MODE_A4, 1)
                store.save(n)
                openNote(n.id)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renameDialog(cur: String, done: (String) -> Unit) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0) }
        val et = EditText(this).apply { setText(cur); setSelectAllOnFocus(true); setSingleLine() }
        col.addView(et)
        AlertDialog.Builder(this).setTitle("Name").setView(col)
            .setPositiveButton("OK") { _, _ -> done(et.text.toString().trim().ifEmpty { "Untitled" }) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun noteMenu(n: Note) {
        AlertDialog.Builder(this).setTitle(n.title)
            .setItems(arrayOf("Open", "Rename", "Duplicate", "Export this note (JSON file)", "Delete")) { _, w ->
                when (w) {
                    0 -> openNote(n.id)
                    1 -> renameDialog(n.title) { t ->
                        val full = store.load(n.id)
                        if (full != null) { full.title = t; store.save(full) }
                        showLibrary()
                    }
                    2 -> {
                        val full = store.load(n.id)
                        if (full != null) {
                            val old = full.id
                            full.id = store.newId(); full.title = n.title + " copy"
                            full.created = System.currentTimeMillis(); full.modified = full.created
                            store.save(full)
                            try { if (store.thumbFile(old).exists()) store.thumbFile(old).copyTo(store.thumbFile(full.id), true) } catch (ex: Exception) { }
                        }
                        showLibrary()
                    }
                    3 -> startBackup(listOf(n.id), n.title)
                    4 -> AlertDialog.Builder(this).setTitle("Delete \"${n.title}\"?")
                        .setMessage("This note will be removed from this phone. A backup file you made earlier is not affected.")
                        .setPositiveButton("Delete") { _, _ -> store.delete(n.id); showLibrary() }
                        .setNegativeButton("Cancel", null).show()
                }
            }.show()
    }

    private fun openNote(id: String) {
        val n = store.load(id)
        if (n == null) { say("This note could not be opened"); return }
        draw.loadNote(n)
        inEditor = true; dirty = false; toolsOpen = true; writingNow = false
        titleChip.text = n.title; savedChip.text = "Saved"
        setContentView(editor)
        applyBars(cfg.immersive)
        applyCfg()
        refreshToolbar()
    }

    private fun closeNote() {
        saveNow(true, true)
        if (isPinned()) try { stopLockTask() } catch (ex: Exception) { }
        showLibrary()
    }

    // =====================================================================
    // backup and restore (JSON files)
    // =====================================================================

    private fun safeName(s: String): String = s.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifEmpty { "note" }

    /** ids = null: all notes plus settings. Otherwise only those notes. */
    private fun startBackup(ids: List<String>?, title: String = "") {
        if (inEditor) saveNow(true, false)
        pendingIds = ids
        val stampName = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        val name = if (ids == null) "stylus-notes-backup-$stampName.json" else safeName(title) + "-$stampName.json"
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, name)
        }
        try { startActivityForResult(i, if (ids == null) REQ_BACKUP else REQ_EXPORT) } catch (ex: Exception) { say("No file picker found on this phone") }
    }

    private fun startRestore() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "application/octet-stream"))
        }
        try { startActivityForResult(i, REQ_RESTORE) } catch (ex: Exception) { say("No file picker found on this phone") }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        when (req) {
            REQ_BACKUP, REQ_EXPORT -> {
                val ids = if (req == REQ_EXPORT) pendingIds else null
                val withSettings = req == REQ_BACKUP
                exec.execute {
                    var err: String? = null
                    try {
                        val os = contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("cannot write there")
                        os.use { store.writeBackup(it, ids, if (withSettings) cfg.prefs else null) }
                    } catch (ex: Exception) { err = ex.message ?: "unknown error" }
                    runOnUiThread { say(if (err == null) "Backup saved. Keep the file somewhere safe (Drive, PC, another phone)." else "Backup failed: $err") }
                }
            }
            REQ_RESTORE -> exec.execute {
                try {
                    val ins = contentResolver.openInputStream(uri) ?: throw IllegalStateException("cannot read that file")
                    val d = ins.use { store.readBackup(it) }
                    runOnUiThread { confirmRestore(d) }
                } catch (ex: Exception) {
                    runOnUiThread { say("Could not read this file: " + (ex.message ?: "not a valid backup")) }
                }
            }
        }
    }

    private fun confirmRestore(d: ImportData) {
        val clash = d.notes.count { store.exists(it.id) }
        if (clash == 0) { doRestore(d, 0); return }
        AlertDialog.Builder(this).setTitle("$clash of ${d.notes.size} notes already exist")
            .setMessage("Replace them with the backup version, keep both, or skip those?")
            .setPositiveButton("Replace") { _, _ -> doRestore(d, 0) }
            .setNeutralButton("Keep both") { _, _ -> doRestore(d, 1) }
            .setNegativeButton("Skip") { _, _ -> doRestore(d, 2) }.show()
    }

    /** how: 0 replace, 1 keep both, 2 skip existing */
    private fun doRestore(d: ImportData, how: Int) {
        exec.execute {
            var added = 0; var replaced = 0; var skipped = 0
            for (n in d.notes) {
                val exists = store.exists(n.id)
                if (exists && how == 2) { skipped++; continue }
                if (exists && how == 1) { n.id = store.newId(); n.title = n.title + " (restored)"; added++ }
                else if (exists) replaced++ else added++
                store.save(n)
            }
            runOnUiThread {
                if (d.settings.isNotEmpty()) {
                    val ed = cfg.prefs.edit()
                    for ((k, v) in d.settings) {
                        if (k in Cfg.DEVICE_KEYS) continue
                        when (v) { is Boolean -> ed.putBoolean(k, v); is Int -> ed.putInt(k, v); is String -> ed.putString(k, v) }
                    }
                    ed.apply(); cfg.load()
                }
                say("Restored: $added new, $replaced replaced, $skipped skipped")
                showLibrary()
            }
        }
    }

    // =====================================================================
    // settings
    // =====================================================================

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title; textSize = 17f; setTextColor(accent); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(2))
        })
    }

    private fun note(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply { this.text = text; textSize = 12f; setTextColor(0xFF666666.toInt()); setPadding(0, dp(4), 0, dp(2)) })
    }

    private fun segmented(parent: LinearLayout, label: String, options: List<String>, current: Int, onPick: (Int) -> Unit) {
        parent.addView(TextView(this).apply { text = label; textSize = 14f; setPadding(0, dp(12), 0, dp(4)) })
        val row = LinearLayout(this)
        val views = ArrayList<TextView>()
        fun paintSel(sel: Int) {
            for ((i, v) in views.withIndex()) {
                v.background = rr(if (i == sel) accent else 0xFFE6E8EE.toInt(), 10)
                v.setTextColor(if (i == sel) Color.WHITE else 0xFF333333.toInt())
            }
        }
        for ((i, o) in options.withIndex()) {
            val v = TextView(this).apply {
                text = o; gravity = Gravity.CENTER; textSize = 13f
                setPadding(dp(4), dp(10), dp(4), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
            }
            v.setOnClickListener { paintSel(i); onPick(i); draw.invalidate() }
            views.add(v); row.addView(v)
        }
        paintSel(current)
        parent.addView(row)
    }

    private fun slider(parent: LinearLayout, label: String, vMin: Int, vMax: Int, cur: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
        val tv = TextView(this).apply { textSize = 14f; setPadding(0, dp(12), 0, 0) }
        tv.text = label + ": " + fmt(cur)
        val sb = SeekBar(this)
        sb.max = vMax - vMin
        sb.progress = cur - vMin
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + vMin
                tv.text = label + ": " + fmt(v)
                if (fromUser) { onChange(v); draw.invalidate() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv); parent.addView(sb)
    }

    private fun toggle(parent: LinearLayout, label: String, cur: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = label; sw.textSize = 14f; sw.isChecked = cur
        sw.setPadding(0, dp(10), 0, dp(10))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw)
    }

    private fun btn(parent: LinearLayout, label: String, f: () -> Unit) {
        parent.addView(Button(this).apply { text = label; isAllCaps = false; setOnClickListener { f() } })
    }

    private fun showReport() {
        val text = draw.rec.report(resources.displayMetrics, draw.statusText(), cfg.strict)
        val tv = TextView(this).apply {
            this.text = text; textSize = 10f; typeface = Typeface.MONOSPACE
            setTextIsSelectable(true); setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val sv = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this).setTitle("Report").setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("stylus report", text))
                say("Report copied. Paste it into the chat.")
            }
            .setNeutralButton("Share") { _, _ ->
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                startActivity(Intent.createChooser(i, "Send report"))
            }
            .setNegativeButton("Close", null).show()
    }

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(12)) }
        val sv = ScrollView(this).apply { addView(col) }
        var dlg: AlertDialog? = null

        section(col, "This note")
        note(col, "Saved automatically a moment after every stroke, and when you leave. Backups are JSON files you choose where to keep.")
        btn(col, "Save now") { saveNow(true, false); say("Saved") }
        btn(col, "Back up ALL notes (JSON file)") { dlg?.dismiss(); startBackup(null) }
        btn(col, "Export only this note (JSON file)") { dlg?.dismiss(); startBackup(listOf(draw.note.id), draw.note.title) }

        section(col, "Writing lock (no minimising, no peeking bars)")
        toggle(col, "Hide status and navigation bars", cfg.immersive) { cfg.immersive = it; cfg.save(); applyBars(it) }
        toggle(col, "Block edge swipes while writing", cfg.blockGestures) { cfg.blockGestures = it; cfg.save(); draw.blockGestures = it }
        toggle(col, "Hide the tool bar while the pen is writing", cfg.hideWhileWriting) { cfg.hideWhileWriting = it; cfg.save(); refreshChrome() }
        btn(col, "Lock / unlock app on screen (screen pinning)") { dlg?.dismiss(); togglePin() }
        note(col, "Screen pinning is the strongest lock: Home and Recents stop working until you unlock.")

        section(col, "Move around the page")
        toggle(col, "Auto-move when the pen reaches the edge (like Excel)", cfg.autoScroll) { cfg.autoScroll = it; cfg.save() }
        slider(col, "Edge zone", 24, 120, cfg.edgeZone, { "$it dp" }) { cfg.edgeZone = it; cfg.save() }
        slider(col, "Auto-move speed", 1, 15, cfg.scrollSpeed, { "$it" }) { cfg.scrollSpeed = it; cfg.save() }
        toggle(col, "A4: add a new page at the end automatically", cfg.autoPage) { cfg.autoPage = it; cfg.save() }
        note(col, "Also: Move button = arrow pad, Hand button = the pen drags the page, + and \u2212 zoom, Fit = page fills the width. Fingers never move the page.")

        section(col, "Paper")
        segmented(col, "Page style", listOf("Blank", "Lines", "Grid", "Dots"), cfg.paper) { cfg.paper = it; cfg.save() }
        segmented(col, "Paper colour", Cfg.PAPER_NAMES, cfg.paperColor) { cfg.paperColor = it; cfg.save() }
        segmented(col, "Line colour", Cfg.LINE_NAMES, cfg.lineColor) { cfg.lineColor = it; cfg.save() }
        slider(col, "Line spacing", 14, 60, cfg.spacing, { "$it" }) { cfg.spacing = it; cfg.save() }

        section(col, "A4 margins")
        toggle(col, "Left margin line (red)", cfg.leftMargin) { cfg.leftMargin = it; cfg.save(); draw.invalidate() }
        slider(col, "Left margin position", 0, 200, cfg.leftMarginPos, { "$it" }) { cfg.leftMarginPos = it; cfg.save() }
        slider(col, "Top margin (space before first line)", 0, 240, cfg.topMargin, { "$it" }) { cfg.topMargin = it; cfg.save() }

        section(col, "Pen")
        slider(col, "Pen thickness", 1, 40, cfg.pen, { "${it / 2f}" }) { cfg.pen = it; cfg.save() }
        slider(col, "Eraser size", 6, 120, cfg.eraser, { "$it" }) { cfg.eraser = it; cfg.save() }

        section(col, "Auto-clean (draw everything, erase hand marks)")
        toggle(col, "Every touch draws; marks from resting fingers and palm erase by themselves", cfg.autoClean) { cfg.autoClean = it; cfg.save() }
        note(col, "Use this when the phone cannot tell the stylus from the hand. A touch that rests, flutters or drifts slowly while you write disappears when it is judged to be a hand. Pen lines continue after Android cuts them if you touch again within a moment. Turn off Allow dots if finger taps leave dots.")

        section(col, "Stylus identification")
        val st = TextView(this).apply { text = draw.statusText(); textSize = 13f; setPadding(0, dp(4), 0, dp(8)) }
        col.addView(st)
        slider(col, "Finger and palm rejection strictness", 0, 100, cfg.strict, { "$it%" }) { cfg.strict = it; cfg.save() }
        note(col, "Higher = a touch must match your stylus fingerprint very closely to draw. If the stylus gets ignored, lower it. If fingers still draw, raise it. The bottom left box shows why each touch was accepted or refused.")
        toggle(col, "Allow dots from taps (turn off if fingers still make dots)", cfg.dots) { cfg.dots = it; cfg.save() }
        toggle(col, "Show touch info (bottom left)", cfg.showInfo) { cfg.showInfo = it; cfg.save(); refreshChrome() }
        toggle(col, "Keep screen on while writing", cfg.keepOn) { cfg.keepOn = it; cfg.save(); draw.keepScreenOn = it }
        fun learnBtn(label: String, kind: String) = btn(col, label) {
            dlg?.dismiss()
            draw.startLearn(kind)
            calText.text = draw.learnHint()
            calBar.visibility = View.VISIBLE
        }
        note(col, "Do the three steps in order. Each one shows a counter and tells you what to do next. More samples = better recognition.")
        learnBtn("1. Learn stylus (15 lines, guided)", "stylus")
        learnBtn("2. Learn fingers and palm (no stylus)", "finger")
        learnBtn("3. Learn my hand: write naturally, hand resting", "natural")
        btn(col, "Forget what was learned") { draw.resetLearning(); st.text = draw.statusText() }

        section(col, "Report (copy it and send it to Claude)")
        note(col, "After the three learn steps, open the report, press Copy, and paste it into the chat. It shows what this phone reports, how well each measurement separates the stylus from your hand, and which rule picks the pen.")
        btn(col, "Show and copy the report") { showReport() }
        btn(col, "Clear recorded touches") { draw.rec.clearAll(); say("Recorded touches cleared") }

        section(col, "Page")
        btn(col, "Clear this note") {
            AlertDialog.Builder(this@MainActivity).setTitle("Clear everything in this note?")
                .setPositiveButton("Clear") { _, _ -> draw.clearAll() }
                .setNegativeButton("Cancel", null).show()
        }

        dlg = AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done", null).create()
        dlg.setOnDismissListener { cfg.save(); applyCfg(); if (inEditor) applyBars(cfg.immersive) }
        dlg.show()
    }
}
