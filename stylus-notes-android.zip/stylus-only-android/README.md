# Stylus Notes (Android) - version 3

Write with the stylus only. Fingers and palms never draw and never move the page.

## Get the APK with GitHub (no Android Studio needed)
1. Upload everything in this folder to a GitHub repository (including the hidden `.github` folder and `app/stylus-notes.keystore`).
2. Open the **Actions** tab. "Build APK" runs by itself (or press "Run workflow").
3. When it is green, download **stylus-only-apk** at the bottom of the run, unzip, copy `app-debug.apk` to the phone and install.
4. From version 3 on every build uses the same signing key, so a new APK installs OVER the old one and your notes stay.
   Only the first switch from an older build needs an uninstall (the old app had one single page; it is moved into a note called "My first page" if the app can read it, so install over it if Android allows).

## Notes list (like Draw Notes)
- **+ New note**: choose **A4 sheet** (default) or **Unlimited space**.
- Every note saves itself a moment after each stroke and when you leave. The **Save** button saves at once.
- Tap a note to open it. The three dots (or long press) give Rename, Duplicate, Export this note, Delete.
- **Backup**: writes ALL notes plus your settings into one `.json` file. You choose where (Downloads, Drive, a PC...).
- **Restore**: pick a backup `.json`. If a note already exists you choose Replace, Keep both or Skip.
- Settings > This note: Save now, Back up all, Export only this note.

## A4 and unlimited
- A4: pages 595 x 842 units stacked downwards, red margin, ruled lines. **+ Page** adds a page; it also adds one by itself when you reach the end.
- Unlimited: endless in every direction.

## Moving around (no fingers)
- **Auto-move like Excel**: hold the pen near a screen edge for a moment and the page slides by itself, and the line you are drawing keeps growing. Speed and edge size are in Settings.
- **Move** button: arrow pad (press and hold) plus page up and page down.
- **Hand** button: the pen drags the page.
- **+ / - / Fit**: zoom. A thin bar on the right shows where you are on a tall A4 note.

## Writing lock (no minimising, no peeking bars)
- Status and navigation bars hidden in the editor, edge swipes blocked, tool bar hidden while the pen writes and back a moment later.
- Back button is ignored while the pen is writing.
- **Lock** button = Android screen pinning: Home and Recents stop working until you tap Unlock (or hold Back + Overview).
  If nothing happens, switch on Phone Settings > Security > Screen pinning.

## Stylus identification
Settings > Stylus identification: **1. Learn stylus** (8+ short lines with ONLY the stylus, Done), then **2. Learn fingers and palm**.
- If the phone reports your pen as a real pen, the app locks onto that signal: ONLY the pen can draw.
- Otherwise it learns six things about the pen tip: size, minor axis, pressure, area, roundness and steadiness (a finger wobbles, a pen tip does not).
- Learn again once after installing version 3.
- The bottom-left box tells you why a touch was accepted or refused.
