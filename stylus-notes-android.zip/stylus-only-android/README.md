# Stylus Notes (Android)

Write with the stylus only. Palms and fingers are ignored. Two fingers move and zoom the page.

## Get the APK with GitHub (no Android Studio needed)
1. Upload everything in this folder to a GitHub repository (including the hidden `.github` folder).
2. Open the **Actions** tab. "Build APK" runs by itself (or press "Run workflow").
3. When it is green, download **stylus-only-apk** at the bottom of the run and unzip it.
4. Copy `app-debug.apk` to the phone and install it.
   If Android refuses to update the old version, uninstall the old app first (each GitHub build is signed with a new debug key).

## First time
Settings > **1. Learn stylus**: draw 5+ short lines with only the stylus, tap Done.
Settings > **2. Learn fingers and palm**: touch 8+ times with fingers, two fingers, and the whole hand, tap Done.

## Features
- Palm and fingers resting on the screen while the stylus writes: only the stylus draws.
- Two fingers: move the page. Pinch: zoom. (Does nothing while the stylus is writing.)
- Full screen button, small dots at top left bring the tools back, Back button exits.
- Notebook settings: lines, grid or dots, paper colour, line spacing, left margin line, top margin.
- Pen thickness, eraser size, 5 ink colours, undo, redo. Your page is saved automatically.
